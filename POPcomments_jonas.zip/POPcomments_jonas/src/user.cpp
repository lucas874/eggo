#include "user.h"

/*
 * Implementation of the User class
 */

// Public method for getting name of user
std::string User::getName() {
	return name;
}

// Public method for getting password of user
std::string User::getPass() {
	return password;
}


// Public method for getting path of user's folder
std::string User::getPath() {
	return path;
}

// Public method for getting path of user's inbox folder
std::string User::getInboxPath() {
	std::string str = path;
	str += "/";
	str += "Inbox";
	str += "/";
	return str;
}

// Add mail to inbox
void User::addMail(PieceOfMail* p) {
	inbox.push_back(p);
}


// Public method for returning size of user's inbox (amount of mails)
int User::getInboxSize() {
	return inbox.size();
}


// Public method for returning size of user's inbox (in octets)
int User::getInboxSizeOctets() {
	int sz = 0;
	for(auto &itr : inbox) {
		sz += sizeof(itr->getContent());
	}
	return sz;
}


// Public method for returning size of mail with specific index
int User::getMailSize(int index) {
	if(inbox.size() == 0)
		return -1;
	if(index < 0 || index >= inbox.size())
		return -1;
	return sizeof(inbox[index]->getContent());
}


// Public method for getting content of a mail with specific index as a string
std::string User::getMailContent(int index) {
	return inbox[index]->getContent();
}

// Public method for deleting a mail from user's inbox
void User::deleteMail(int index) {
	inbox.erase(inbox.begin()+index);
}
