#include "event.h"

Event::Event(enum POP_Events event, std::string data) {
    _event = event;
    _data = data;
    for(int i = 0; i < 8; i++) {
	    if(i < 2)
		    stateNumbers[i] = 0;
	    else
		    stateNumbers[i] = 1;
    }
}

std::string Event::getData() {
  return _data;
}

int Event::getEventNo() {
  return _event;
}

int Event::getStateNo() {
	return stateNumbers[getEventNo()];
}




 
