#ifndef POPSTATE_H
#define POPSTATE_H
#include "event.h"
class POPsession;

class POPstate {
	public:
		virtual void Close(POPsession*);
		virtual void Send(POPsession*);
  		virtual void Action(POPsession*, Event*);
  		virtual void ChangeState(POPsession*, int);
  		virtual int getStateNo();
 };



#endif 

