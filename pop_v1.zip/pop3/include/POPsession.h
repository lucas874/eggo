#ifndef POPSESSION_H
#define POPSESSION_H

#include "POPstate.h"
#include "event.h"
#include <zmq.hpp>
#include <unistd.h>
class POPsession {
	public:
		POPsession(std::vector<POPstate*>);
		void Run();
		void ChangeState(Event*);
		void StateAction();
		void Reply(int);
		void Close();
		Event* ProcessRequest(std::string buffer);

	private:
		void ChangeState(POPstate*);
		friend class POPState;
  		friend class POPauthorization;
  		friend class POPtransaction;
  		friend class POPupdate;
  		
		POPstate* currentState;
		std::vector<POPstate*> states;
		zmq::context_t context;
		zmq::socket_t socket;
		Event* currentevent;
};
#endif 
