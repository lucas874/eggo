#ifndef EVENT_H
#define EVENT_H

#include <iostream>

enum Events {AUTHORIZATION, TRANSACTION, UPDATE};

class Event {
	public:
		Event(enum Events e, std::string data);
		int getEventNo();
		std::string getData();
	private:
		enum Events _event;
		std::string *_data;
};

#endif
