#include "POPstate.h"

// inject POPsession in constructor!!
void POPstate::Close(POPsession*) { }
void POPstate::Send(POPsession*) { }
void POPstate::Action(POPsession*, Event*) { }
void POPstate::ChangeState(POPsession*, int) { }
int POPstate::getStateNo() {}
