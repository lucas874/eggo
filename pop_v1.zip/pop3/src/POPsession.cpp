#include "POPsession.h"


POPsession::POPsession(std::vector<POPstate*> v)
	: states(v)
	, currentState(v[0])
	, context(1)
	, socket(context, zmq::socket_type::rep)
	{
		socket.bind("tcp://*:5556");
	}


void POPsession::Run() {
	while(1) {
		zmq::message_t rawrequest;
    		socket.recv(rawrequest, zmq::recv_flags::none);
    		std::string request = rawrequest.to_string();
    		std::cout << "Received " << request << std::endl;

        	Event *e = ProcessRequest(request);
		currentevent = e;
	    	ChangeState(e);
	    	currentState->Action(this, e);
		sleep(1);
	}
}

void POPsession::Close() {
	std::cout << "hej";
}

void POPsession::Reply(int replycode) {
	std::string buffer;
  	buffer = "HEJ"; 
  	socket.send(zmq::buffer(buffer), zmq::send_flags::none);
}


Event* POPsession::ProcessRequest(std::string buffer) {

	enum Events e;

	if(buffer.compare("authorization") == 0)
		e = AUTHORIZATION;
	else if(buffer.compare("transaction") == 0)
		e = TRANSACTION;
	else if(buffer.compare("update") == 0)
		e = UPDATE;


	Event* event = new Event(e, buffer);
	return event;
	
}

void POPsession::ChangeState(Event* e)  {
       currentState->ChangeState(this, e->getEventNo());
} 
