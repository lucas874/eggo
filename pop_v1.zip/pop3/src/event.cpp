#include "event.h"

Event::Event(enum Events event, std::string data) {
    _event = event;
    _data = new std::string;
    *_data = data;
}

std::string Event::getData() {
  return *_data;
}

int Event::getEventNo() {
  return _event;
}






 
