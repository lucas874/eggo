#include "POPstates.h"
#include "POPsession.h"

/*             0     	      1     	   2     
 * enum Event {AUTHORIZATION, TRANSACTION, UPDATE};
 *
 */


void POPauthorization::Action(POPsession* ps, Event* ) {
	std::cout << "Hello from AUTHORIZATION state" << std::endl;
	ps->Reply(1);
}

void POPauthorization::ChangeState(POPsession* ps, int n) {
	if(allowedTransitions[n])
		ps->currentState = ps->states[n];
}

int POPauthorization::getStateNo() {
	return stateNo;
}

void POPtransaction::Action(POPsession* ps, Event* ) {
	std::cout << "Hello from TRANSACTION state" << std::endl;
	ps->Reply(1);
}

void POPtransaction::ChangeState(POPsession* ps, int n) {
	if(allowedTransitions[n])
		ps->currentState = ps->states[n];
}

int POPtransaction::getStateNo() {
	return stateNo;
}

void POPupdate::Action(POPsession* ps, Event* ) {
	std::cout << "Hello from UPDATE state" << std::endl;
	ps->Reply(1);
}

void POPupdate::ChangeState(POPsession* ps, int n) {
	if(allowedTransitions[n])
		ps->currentState = ps->states[n];
}

int POPupdate::getStateNo() {
	return stateNo;
}


