#include "POPsession.h"
#include <iostream>
#include "POPstates.h"


using namespace std;

vector<POPstate*> initializeV() {
  vector<POPstate*> v(3);
  v[0] = new POPauthorization();
  v[1] = new POPtransaction();
  v[2] = new POPupdate;
  return v;
}
  
int main() {
  
  vector<POPstate*> v = initializeV();

  POPsession PS(v);  

  PS.Run();
}

