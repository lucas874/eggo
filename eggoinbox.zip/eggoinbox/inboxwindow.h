#ifndef INBOXWINDOW_H
#define INBOXWINDOW_H

#include "pieceofmail.h"

namespace Ui {
class Inboxwindow;
}

class Inboxwindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit Inboxwindow(QWidget *parent = 0);
    ~Inboxwindow();
    void setinbox( );
    void delete_m(int index);
    void open(int index);
    bool checkbox(int index);
    std::string currentUser;
    std::string currentpass;

private slots:
    void on_actionNew_triggered();
    void on_actionExit_triggered();
    void on_pushButton_sendmail_clicked();
    void on_pushButton_nextpage_clicked();
    void on_actionOpen_triggered();
    void on_pushButton_delete_clicked();
    void on_pushButton_prevpage_clicked();
    void on_checkBox_read_clicked();

    void on_pushButton_open_clicked();

    void on_pushButton_open_2_clicked();

    void on_pushButton_open_3_clicked();

    void on_pushButton_open_4_clicked();

    void on_pushButton_open_5_clicked();

    void on_pushButton_open_6_clicked();

    void on_pushButton_open_7_clicked();

    void on_pushButton_open_10_clicked();

    void on_pushButton_open_12_clicked();

    void on_pushButton_open_13_clicked();

    void on_checkBox_read_10_clicked();

    void on_checkBox_read_2_clicked();

    void on_checkBox_read_3_clicked();

    void on_checkBox_read_4_clicked();

    void on_checkBox_read_5_clicked();

    void on_checkBox_read_6_clicked();

    void on_checkBox_read_7_clicked();

    void on_checkBox_read_8_clicked();

    void on_checkBox_read_9_clicked();

    void on_pushButton_forward_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_forward_2_clicked();

    void on_pushButton_forward_3_clicked();

    void on_pushButton_forward_4_clicked();

    void on_pushButton_forward_5_clicked();

    void on_pushButton_forward_6_clicked();

    void on_pushButton_forward_7_clicked();

    void on_pushButton_forward_10_clicked();

    void on_pushButton_forward_12_clicked();

    void on_pushButton_forward_13_clicked();

    void on_pushButton_delete_2_clicked();

    void on_pushButton_delete_3_clicked();

    void on_pushButton_delete_4_clicked();

    void on_pushButton_delete_5_clicked();

    void on_pushButton_delete_6_clicked();

    void on_pushButton_delete_7_clicked();

    void on_pushButton_delete_10_clicked();

    void on_pushButton_delete_12_clicked();

    void on_pushButton_delete_13_clicked();

private:
    void markasread(int index);
    void markasunread(int index);
    bool getreadstatus(int index);
    int getInbox();
    void forward(int index);
    std::string msg(std::string request,zmq::socket_t *socket);
    std::string receive(zmq::socket_t *socket);
    Ui::Inboxwindow *ui;
    std::vector<PieceOfMail *> mailVec;
    int page_count =1;
    zmq::context_t context{1};
    zmq::socket_t *socket1;
    zmq::socket_t *socket2;
    zmq::socket_t *socket3;
    void quickLogin();
};

#endif // INBOXWINDOW_H
