#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H
//#include <QMessageBox>
#include <QPixmap>
#include <QMainWindow>
//#include <QTextStream>
//#include <zmq.hpp>
#include <string>
#include <vector>
#include <iostream>
//#include <stdlib.h>
#include "inboxwindow.h"
#include "registerwindow.h"

namespace Ui {
class loginwindow;
}

class loginwindow : public QMainWindow
{
    Q_OBJECT

    public:
        explicit loginwindow(QWidget *parent = 0);
        ~loginwindow();

    public:
        int login(std::string user,std::string pass);
        void openinboxwindow(std::string name,std::string pass);
        void openregisterwindow();

    private:
        Inboxwindow *theinboxwindow;
        registerwindow *theregisterwindow;
        Ui::loginwindow *ui;
        QVector<std::string> mails;

    private slots:
        void on_pushButton_login_clicked();
        void on_pushButton_register_clicked();
};

#endif // LOGINWINDOW_H
