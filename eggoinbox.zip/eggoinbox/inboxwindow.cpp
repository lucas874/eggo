#include "inboxwindow.h"
#include "ui_inboxwindow.h"
#include <iostream>

Inboxwindow::Inboxwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Inboxwindow)
{
    socket1 = new zmq::socket_t{context, zmq::socket_type::req};
    socket2 = new zmq::socket_t{context, zmq::socket_type::req};
    socket3 = new zmq::socket_t{context, zmq::socket_type::req};
    socket2->connect("tcp://localhost:50001");
    socket1->connect("tcp://localhost:50000");
    socket3->connect("tcp://localhost:50002");
    ui->setupUi(this);
}

Inboxwindow::~Inboxwindow()
{
    delete ui;
}

void Inboxwindow::quickLogin(){

    msg("", socket2);
    std::string userreply = ("USER " + currentUser);
    std::string passreply = ("PASS " + currentpass);
    msg(userreply, socket2);
    msg(passreply, socket2);

}

std::string Inboxwindow::receive(zmq::socket_t *socket){
    zmq::message_t reply{};
    socket->recv(reply, zmq::recv_flags::none);

    std::string str = reply.to_string();
    //qReply = QString::fromStdString(str);
    //return qReply;
    return str;
}

std::string Inboxwindow::msg(std::string request, zmq::socket_t *socket){

    zmq::message_t reply{};
    socket->send(zmq::buffer(request), zmq::send_flags::none);

    socket->recv(reply, zmq::recv_flags::none);

    std::string str = reply.to_string();

    return str;
}

int Inboxwindow::getInbox(){
    //enable connection
    quickLogin();
    //get inboxsize
    std::string str = msg("STAT",socket2);
    std::string substr = str.substr(4,str.size()-4);
    int inboxsize = std::stoi(substr);
    if(inboxsize == 0)
    {

    }
    else{
        for(int i = 0; i < inboxsize; i++){
            PieceOfMail *p = new PieceOfMail;
            std::vector<std::string> newMail;
            std::string is = std::to_string(i);

            std::string str = msg(("RETR " + is), socket2);

            std::string substring = str.substr(6,str.size()-7);
            std::string readstatus = str.substr(4,str.size()-7);
            qDebug() << "readstat" << QString::fromStdString(readstatus);
            if(readstatus.compare("T") == 0) {
                p->markAsRead();
                //ui->
            }
            else{
                p->markAsUnread();
            }
            int lines = std::stoi(substring);
            qDebug() << "lines "<< QString::fromStdString(substring);

            for(int i=0; i < lines; i++){
                switch (i) {
                case 0:

                    p->setsender(msg("",socket2));
                    break;
                case 1:

                    p->setSubject(msg("",socket2));
                    break;
                case 2:

                    p->setrcpt(msg("",socket2));
                    break;
                default:

                    p->append(msg("",socket2));
                    break;
                }
            }
            mailVec.push_back(p);
        }
    }
    return inboxsize;
}

void Inboxwindow::setinbox( )
{
    //PieceOfMail p;
    int ibsize = getInbox();
    if(ibsize == 0)
    {}
    else{
        for(int j=0; j < ibsize ;j++){
            int tmp = (page_count-1) *10 +j;
            QString q_bdsm;
            switch (j) {
            case 0:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_1->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_1->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_1->setText(q_bdsm);
                if(getreadstatus(tmp) == true){
                    ui->checkBox_read->setChecked(1);
                    qDebug() << "true";
                }
                qDebug() << "end 1";
                break;
            case 1:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_2->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_2->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_2->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_2->setChecked(1);
                }
                break;
            case 2:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_3->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_3->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_3->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_3->setChecked(1);
                }

                break;
            case 3:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_4->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_4->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_4->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_4->setChecked(1);
                }
                break;
            case 4:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_5->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_5->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_5->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_5->setChecked(1);
                }
                break;
            case 5:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_6->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_6->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_6->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_6->setChecked(1);
                }
                break;
            case 6:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_7->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_7->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_7->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_7->setChecked(1);
                }

                break;
            case 7:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_10->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_10->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_10->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_8->setChecked(1);
                }
                break;
            case 8:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_12->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_12->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_12->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_9->setChecked(1);
                }
                break;
            case 9:
                q_bdsm = QString::fromStdString(mailVec[tmp]->getSubject());
                ui->lineEdit_subject_13->setText(q_bdsm); //edit line edit to match subject
                q_bdsm = QString::fromStdString(mailVec[tmp]->getrcpt());
                ui->lineEdit_receiver_13->setText(q_bdsm);
                q_bdsm = QString::fromStdString(mailVec[tmp]->getsender());
                ui->lineEdit_sender_13->setText(q_bdsm);
                if(mailVec[tmp]->getReadStatus() == true){
                    ui->checkBox_read_10->setChecked(1);
                }
                break;
            default:
                break;
            }

        }
    }
    msg("QUIT",socket2);
    ui->stackedWidget->setCurrentIndex(0);
}
//quitter til sidst
void Inboxwindow::markasread(int index){
    mailVec[index]->markAsRead();
    msg(("READ " + std::to_string(index)),socket2);
}

void Inboxwindow::markasunread(int index){
    mailVec[index]->markAsUnread();
    msg(("UNRD " + std::to_string(index)),socket2);
}

bool Inboxwindow::getreadstatus(int index){
    return mailVec[index]->getReadStatus();
}

void Inboxwindow::open(int index){
    index = (page_count-1) * 10 + index;
    if(index >= mailVec.size())
    {
    }
    else{
        //mailVec[index]->markAsRead();
        qDebug() << "open";
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_2->setPlainText(q_entire);
        qDebug() << "for";
        QString q_sender = QString::fromStdString(mailVec[index]->getsender());
        ui->lineEdit_sendto_2->setText(q_sender);

        QString q_subject = QString::fromStdString(mailVec[index]->getSubject());
        ui->lineEdit_subject_14->setText(q_subject);
    }
}

bool Inboxwindow::checkbox(int index)//slet
{
   /* index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){ //F for unread T for read
            markasunread(index);
        }
        else{
            markasread(index);
        }*/
   return getreadstatus(index);
}
void Inboxwindow::delete_m(int index){
    std::string str = std::to_string(index);
    quickLogin();
    msg(("DELE " + str),socket2);
    msg("QUIT", socket2);
}

/*
*
* Interactables from this point
*
*
*/
void Inboxwindow::on_actionNew_triggered()
{
    //open text editor
    ui->stackedWidget->setCurrentIndex(1);
}

void Inboxwindow::on_actionOpen_triggered()
{
    //open file select window
    ui->stackedWidget->setCurrentIndex(0);
}

void Inboxwindow::on_actionExit_triggered()
{
    QApplication::quit();
}

void Inboxwindow::on_pushButton_sendmail_clicked()
{
    QString qw_message = ui->plainTextEdit->toPlainText();
    QString qw_subject = ui->lineEdit_subject->text();
    QString qw_sendto = ui->lineEdit_sendto->text();    //

    //socket->connect("tcp://localhost:50000");
    msg("", socket1);
    msg("HELO localhost", socket1);

    std::string sender_email = (currentUser + "@localhost");
    msg("MAIL " + sender_email, socket1);

    std::string recipient = qw_sendto.toStdString();//læs og convert
    msg("RCPT " + recipient, socket1);

    std::string subject = qw_subject.toStdString();
    msg("SUBJ " + subject, socket1);

    msg("DATA", socket1);

    std::string text = qw_message.toStdString(); //læs og convert
    msg(text, socket1);

    msg("\\n.\\n", socket1);

    msg("QUIT", socket1);

    ui->plainTextEdit->clear();
    ui->lineEdit_subject->clear();
    ui->lineEdit_sendto->clear();

}


//---------------------------------------------------------more work needed----------------------------------------------------------------------------
void Inboxwindow::on_pushButton_nextpage_clicked()
{
    int arrsize = 20;
    //ui->label_mails->setText(insert_variable) //used to show the user how many mails they have in their inbox
    int val = page_count*10;
    if( val < arrsize){
        page_count++;
        int max_mail = page_count * 10;
        int min_mail = max_mail - 9;
        std::string max_m = std::to_string(max_mail);
        std::string min_m = std::to_string(min_mail);
        std::string label_text = ("Shown mails are from " + min_m + " to " + max_m);
        QString qlabel_text = QString::fromStdString(label_text);
        ui->label_mail_amount->setText(qlabel_text);
    }
    //setinbox();
}

void Inboxwindow::on_pushButton_prevpage_clicked()
{
    //int arrsize = 20;
    //ui->label_mails->setText(qlabel_text) //used to show the user how many mails they have in their inbox
    if( page_count > 1){
        page_count--;
        int max_mail = page_count * 10;
        int min_mail = max_mail - 9;
        std::string max_m = std::to_string(max_mail);
        std::string min_m = std::to_string(min_mail);
        std::string label_text = ("Shown mails are from " + min_m + " to " + max_m);
        QString qlabel_text = QString::fromStdString(label_text);
        ui->label_mail_amount->setText(qlabel_text);
    }
}

void Inboxwindow::on_pushButton_delete_clicked()
{
    uint index = 0;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_open_clicked() //index 0 copy paste 13
{
    quickLogin();
    uint index = 0;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_2_clicked()
{
    quickLogin();
    uint index = 1;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_2->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_3_clicked()
{
    quickLogin();
    uint index = 2;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_3->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_4_clicked()
{
    quickLogin();
    uint index = 3;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_4->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_5_clicked()//5
{
    quickLogin();
    uint index = 4;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_5->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_6_clicked()
{
    quickLogin();
    uint index = 5;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_6->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_7_clicked()
{
    quickLogin();
    uint index = 6;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_7->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_10_clicked()
{
    quickLogin();
    uint index = 7;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_8->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_12_clicked()
{
    quickLogin();
    uint index = 8;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_9->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_pushButton_open_13_clicked()
{
    quickLogin();
    uint index = 9;
    if(index >= mailVec.size())
    {}
    else{
        ui->stackedWidget->setCurrentIndex(2);
        open(index);
        markasread(index);
        ui->checkBox_read_10->setChecked(1);
    }
    msg("QUIT ",socket2);
}

void Inboxwindow::on_checkBox_read_clicked() //copy paste 10
{
    int index = 0;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read->setChecked(1);
        }
    }
    else{
        ui->checkBox_read->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_2_clicked()
{
    int index = 1;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_2->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_2->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_2->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_3_clicked()
{
    int index = 2;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_3->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_3->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_3->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_4_clicked()
{
    int index = 3;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_4->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_4->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_4->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_5_clicked()
{
    int index = 4;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_5->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_5->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_5->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_6_clicked()
{
    int index = 5;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_6->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_6->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_6->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_7_clicked()
{
    int index = 6;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_7->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_7->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_7->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_8_clicked()
{
    int index = 7;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_8->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_8->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_8->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_9_clicked()
{
    int index = 8;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_9->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_9->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_9->setChecked(0);
    }
    msg(("QUIT "),socket2);
}

void Inboxwindow::on_checkBox_read_10_clicked()
{
    int index = 9;
    //bool checker;
    quickLogin();
    index = (page_count-1) * 10 + index;
    if(index < mailVec.size())
    {
        if(getreadstatus(index) == true){
            markasunread(index);
            ui->checkBox_read_10->setChecked(0);
        }
        else{
            markasread(index);
            ui->checkBox_read_10->setChecked(1);
        }
    }
    else{
        ui->checkBox_read_10->setChecked(0);
    }
    msg(("QUIT "),socket2);
}



void Inboxwindow::on_pushButton_2_clicked()
{
    QString q_subj = ui->lineEdit_4->text();
    QString q_message = ui->plainTextEdit_3->toPlainText();

   // std::string forward_to =
    QString q_forward_to =ui->lineEdit_3->text();

    msg("", socket1);
    msg("HELO localhost", socket1);

    std::string sender_email = (currentUser + "@localhost");
    msg("MAIL " + sender_email, socket1);

    std::string recipient = q_forward_to.toStdString();//læs og convert
    msg("RCPT " + recipient, socket1);

    std::string subject = q_subj.toStdString();
    msg("SUBJ " + subject, socket1);

    msg("DATA", socket1);

    std::string text = q_message.toStdString(); //læs og convert
    msg(text, socket1);

    msg("\\n.\\n", socket1);

    msg("QUIT", socket1);

    ui->plainTextEdit_3->clear();
    ui->lineEdit_3->clear();
    ui->lineEdit_4->clear();
    ui->stackedWidget->setCurrentIndex(0);
}

void Inboxwindow::on_pushButton_clicked()
{
    int index = 0;

    ui->stackedWidget->setCurrentIndex(1);

    std::string subj = ("RE: " +
            mailVec[index]->getSubject());
    QString q_subj = QString::fromStdString(subj);
    std::string message = "";
    QString q_message = QString::fromStdString(message);
    ui->lineEdit_subject->setText(q_subj);
    ui->plainTextEdit->setPlainText(q_message);
    QString q_sender = QString::fromStdString(mailVec[index]->getsender());
    ui->lineEdit_sendto->setText(q_sender);
}

void Inboxwindow::on_pushButton_forward_clicked()
{
    int index = 0;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_2_clicked()
{
    int index = 1;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_3_clicked()
{
    int index = 2;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_4_clicked()
{
    int index = 3;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_5_clicked()
{
    int index = 4;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_6_clicked()
{
    int index = 5;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_7_clicked()
{
    int index = 6;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_10_clicked()
{
    int index = 7;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_12_clicked()
{
    int index = 8;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_forward_13_clicked()
{
    int index = 9;
    if(index < mailVec.size())
    {
        ui->stackedWidget->setCurrentIndex(3);

        std::string subj = ("Fw: " +
                mailVec[index]->getSubject());
        QString q_subj = QString::fromStdString(subj);
        std::vector<std::string> text = mailVec[index]->getContent();
        QString q_entire;
        for(auto i: text){
            q_entire.append(QString::fromStdString(i));
        }
        ui->plainTextEdit_3->setPlainText(q_entire);
        ui->lineEdit_4->setText(q_subj);
    }
}

void Inboxwindow::on_pushButton_delete_2_clicked()
{
    uint index = 1;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_delete_3_clicked()
{
    uint index = 2;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_delete_4_clicked()
{
    uint index = 3;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_delete_5_clicked()
{
    uint index = 4;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_delete_6_clicked()
{
    uint index = 5;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_delete_7_clicked()
{
    uint index = 6;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_delete_10_clicked()
{
    uint index = 7;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_delete_12_clicked()
{
    uint index = 8;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}

void Inboxwindow::on_pushButton_delete_13_clicked()
{
    uint index = 0;
    if(index >= mailVec.size())
    {}
    else{
        delete_m(0);
    }
}
