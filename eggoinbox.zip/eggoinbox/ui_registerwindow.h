/********************************************************************************
** Form generated from reading UI file 'registerwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTERWINDOW_H
#define UI_REGISTERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_registerwindow
{
public:
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *lineEdit_user;
    QLineEdit *lineEdit_pass1;
    QLineEdit *lineEdit_pass2;
    QPushButton *pushButton_register2;

    void setupUi(QDialog *registerwindow)
    {
        if (registerwindow->objectName().isEmpty())
            registerwindow->setObjectName(QStringLiteral("registerwindow"));
        registerwindow->resize(252, 199);
        groupBox = new QGroupBox(registerwindow);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 0, 231, 189));
        verticalLayout_3 = new QVBoxLayout(groupBox);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        lineEdit_user = new QLineEdit(groupBox);
        lineEdit_user->setObjectName(QStringLiteral("lineEdit_user"));

        verticalLayout_2->addWidget(lineEdit_user);

        lineEdit_pass1 = new QLineEdit(groupBox);
        lineEdit_pass1->setObjectName(QStringLiteral("lineEdit_pass1"));
        lineEdit_pass1->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(lineEdit_pass1);

        lineEdit_pass2 = new QLineEdit(groupBox);
        lineEdit_pass2->setObjectName(QStringLiteral("lineEdit_pass2"));
        lineEdit_pass2->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(lineEdit_pass2);


        verticalLayout->addLayout(verticalLayout_2);

        pushButton_register2 = new QPushButton(groupBox);
        pushButton_register2->setObjectName(QStringLiteral("pushButton_register2"));

        verticalLayout->addWidget(pushButton_register2);


        verticalLayout_3->addLayout(verticalLayout);


        retranslateUi(registerwindow);

        QMetaObject::connectSlotsByName(registerwindow);
    } // setupUi

    void retranslateUi(QDialog *registerwindow)
    {
        registerwindow->setWindowTitle(QApplication::translate("registerwindow", "Register", Q_NULLPTR));
        groupBox->setTitle(QString());
        lineEdit_user->setText(QString());
        lineEdit_user->setPlaceholderText(QApplication::translate("registerwindow", "Enter Preffered Username", Q_NULLPTR));
        lineEdit_pass1->setText(QString());
        lineEdit_pass1->setPlaceholderText(QApplication::translate("registerwindow", "Enter Password", Q_NULLPTR));
        lineEdit_pass2->setPlaceholderText(QApplication::translate("registerwindow", "Repeat Password", Q_NULLPTR));
        pushButton_register2->setText(QApplication::translate("registerwindow", "Register", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class registerwindow: public Ui_registerwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTERWINDOW_H
