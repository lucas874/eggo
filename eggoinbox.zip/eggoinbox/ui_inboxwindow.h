/********************************************************************************
** Form generated from reading UI file 'inboxwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INBOXWINDOW_H
#define UI_INBOXWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Inboxwindow
{
public:
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionExit;
    QWidget *centralwidget;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QGroupBox *groupBox_2;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_10;
    QVBoxLayout *verticalLayout_5;
    QLineEdit *lineEdit_subject_1;
    QVBoxLayout *verticalLayout_6;
    QLineEdit *lineEdit_sender_1;
    QVBoxLayout *verticalLayout_7;
    QLineEdit *lineEdit_receiver_1;
    QPushButton *pushButton_open;
    QPushButton *pushButton_forward;
    QPushButton *pushButton_delete;
    QCheckBox *checkBox_read;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *lineEdit_subject_2;
    QLineEdit *lineEdit_sender_2;
    QLineEdit *lineEdit_receiver_2;
    QPushButton *pushButton_open_2;
    QPushButton *pushButton_forward_2;
    QPushButton *pushButton_delete_2;
    QCheckBox *checkBox_read_2;
    QHBoxLayout *horizontalLayout_6;
    QLineEdit *lineEdit_subject_3;
    QLineEdit *lineEdit_sender_3;
    QLineEdit *lineEdit_receiver_3;
    QPushButton *pushButton_open_3;
    QPushButton *pushButton_forward_3;
    QPushButton *pushButton_delete_3;
    QCheckBox *checkBox_read_3;
    QHBoxLayout *horizontalLayout_7;
    QLineEdit *lineEdit_subject_4;
    QLineEdit *lineEdit_sender_4;
    QLineEdit *lineEdit_receiver_4;
    QPushButton *pushButton_open_4;
    QPushButton *pushButton_forward_4;
    QPushButton *pushButton_delete_4;
    QCheckBox *checkBox_read_4;
    QHBoxLayout *horizontalLayout_8;
    QLineEdit *lineEdit_subject_5;
    QLineEdit *lineEdit_sender_5;
    QLineEdit *lineEdit_receiver_5;
    QPushButton *pushButton_open_5;
    QPushButton *pushButton_forward_5;
    QPushButton *pushButton_delete_5;
    QCheckBox *checkBox_read_5;
    QHBoxLayout *horizontalLayout_11;
    QLineEdit *lineEdit_subject_6;
    QLineEdit *lineEdit_sender_6;
    QLineEdit *lineEdit_receiver_6;
    QPushButton *pushButton_open_6;
    QPushButton *pushButton_forward_6;
    QPushButton *pushButton_delete_6;
    QCheckBox *checkBox_read_6;
    QHBoxLayout *horizontalLayout_9;
    QLineEdit *lineEdit_subject_7;
    QLineEdit *lineEdit_sender_7;
    QLineEdit *lineEdit_receiver_7;
    QPushButton *pushButton_open_7;
    QPushButton *pushButton_forward_7;
    QPushButton *pushButton_delete_7;
    QCheckBox *checkBox_read_7;
    QHBoxLayout *horizontalLayout_14;
    QLineEdit *lineEdit_subject_10;
    QLineEdit *lineEdit_sender_10;
    QLineEdit *lineEdit_receiver_10;
    QPushButton *pushButton_open_10;
    QPushButton *pushButton_forward_10;
    QPushButton *pushButton_delete_10;
    QCheckBox *checkBox_read_8;
    QHBoxLayout *horizontalLayout_16;
    QLineEdit *lineEdit_subject_12;
    QLineEdit *lineEdit_sender_12;
    QLineEdit *lineEdit_receiver_12;
    QPushButton *pushButton_open_12;
    QPushButton *pushButton_forward_12;
    QPushButton *pushButton_delete_12;
    QCheckBox *checkBox_read_9;
    QHBoxLayout *horizontalLayout_17;
    QLineEdit *lineEdit_subject_13;
    QLineEdit *lineEdit_sender_13;
    QLineEdit *lineEdit_receiver_13;
    QPushButton *pushButton_open_13;
    QPushButton *pushButton_forward_13;
    QPushButton *pushButton_delete_13;
    QCheckBox *checkBox_read_10;
    QLabel *label_mail_amount;
    QLabel *label_mails;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton_prevpage;
    QPushButton *pushButton_nextpage;
    QWidget *page_2;
    QGroupBox *groupBox;
    QPushButton *pushButton_sendmail;
    QPlainTextEdit *plainTextEdit;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *lineEdit_sendto;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit_subject;
    QWidget *page_3;
    QGroupBox *groupBox_3;
    QPlainTextEdit *plainTextEdit_2;
    QWidget *layoutWidget_7;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_3;
    QLineEdit *lineEdit_sendto_2;
    QWidget *layoutWidget_8;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_4;
    QLineEdit *lineEdit_subject_14;
    QPushButton *pushButton;
    QWidget *page_4;
    QGroupBox *groupBox_4;
    QPlainTextEdit *plainTextEdit_3;
    QWidget *layoutWidget_9;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_5;
    QLineEdit *lineEdit_3;
    QWidget *layoutWidget_10;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_9;
    QLineEdit *lineEdit_4;
    QPushButton *pushButton_2;
    QMenuBar *menubar;
    QMenu *menuFile;
    QStatusBar *statusbar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *Inboxwindow)
    {
        if (Inboxwindow->objectName().isEmpty())
            Inboxwindow->setObjectName(QStringLiteral("Inboxwindow"));
        Inboxwindow->resize(778, 604);
        actionNew = new QAction(Inboxwindow);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/new.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNew->setIcon(icon);
        actionOpen = new QAction(Inboxwindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpen->setIcon(icon1);
        actionExit = new QAction(Inboxwindow);
        actionExit->setObjectName(QStringLiteral("actionExit"));
        centralwidget = new QWidget(Inboxwindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(30, 30, 671, 521));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        groupBox_2 = new QGroupBox(page);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(0, 10, 661, 461));
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(20, 30, 142, 17));
        label_7 = new QLabel(groupBox_2);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(130, 30, 142, 17));
        label_8 = new QLabel(groupBox_2);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(240, 30, 142, 17));
        layoutWidget = new QWidget(groupBox_2);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 50, 631, 328));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(0);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        lineEdit_subject_1 = new QLineEdit(layoutWidget);
        lineEdit_subject_1->setObjectName(QStringLiteral("lineEdit_subject_1"));

        verticalLayout_5->addWidget(lineEdit_subject_1);


        horizontalLayout_10->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        lineEdit_sender_1 = new QLineEdit(layoutWidget);
        lineEdit_sender_1->setObjectName(QStringLiteral("lineEdit_sender_1"));

        verticalLayout_6->addWidget(lineEdit_sender_1);


        horizontalLayout_10->addLayout(verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        lineEdit_receiver_1 = new QLineEdit(layoutWidget);
        lineEdit_receiver_1->setObjectName(QStringLiteral("lineEdit_receiver_1"));

        verticalLayout_7->addWidget(lineEdit_receiver_1);


        horizontalLayout_10->addLayout(verticalLayout_7);

        pushButton_open = new QPushButton(layoutWidget);
        pushButton_open->setObjectName(QStringLiteral("pushButton_open"));

        horizontalLayout_10->addWidget(pushButton_open);

        pushButton_forward = new QPushButton(layoutWidget);
        pushButton_forward->setObjectName(QStringLiteral("pushButton_forward"));

        horizontalLayout_10->addWidget(pushButton_forward);

        pushButton_delete = new QPushButton(layoutWidget);
        pushButton_delete->setObjectName(QStringLiteral("pushButton_delete"));

        horizontalLayout_10->addWidget(pushButton_delete);

        checkBox_read = new QCheckBox(layoutWidget);
        checkBox_read->setObjectName(QStringLiteral("checkBox_read"));

        horizontalLayout_10->addWidget(checkBox_read);


        verticalLayout->addLayout(horizontalLayout_10);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(0);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        lineEdit_subject_2 = new QLineEdit(layoutWidget);
        lineEdit_subject_2->setObjectName(QStringLiteral("lineEdit_subject_2"));

        horizontalLayout_5->addWidget(lineEdit_subject_2);

        lineEdit_sender_2 = new QLineEdit(layoutWidget);
        lineEdit_sender_2->setObjectName(QStringLiteral("lineEdit_sender_2"));

        horizontalLayout_5->addWidget(lineEdit_sender_2);

        lineEdit_receiver_2 = new QLineEdit(layoutWidget);
        lineEdit_receiver_2->setObjectName(QStringLiteral("lineEdit_receiver_2"));

        horizontalLayout_5->addWidget(lineEdit_receiver_2);

        pushButton_open_2 = new QPushButton(layoutWidget);
        pushButton_open_2->setObjectName(QStringLiteral("pushButton_open_2"));

        horizontalLayout_5->addWidget(pushButton_open_2);

        pushButton_forward_2 = new QPushButton(layoutWidget);
        pushButton_forward_2->setObjectName(QStringLiteral("pushButton_forward_2"));

        horizontalLayout_5->addWidget(pushButton_forward_2);

        pushButton_delete_2 = new QPushButton(layoutWidget);
        pushButton_delete_2->setObjectName(QStringLiteral("pushButton_delete_2"));

        horizontalLayout_5->addWidget(pushButton_delete_2);

        checkBox_read_2 = new QCheckBox(layoutWidget);
        checkBox_read_2->setObjectName(QStringLiteral("checkBox_read_2"));

        horizontalLayout_5->addWidget(checkBox_read_2);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(0);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        lineEdit_subject_3 = new QLineEdit(layoutWidget);
        lineEdit_subject_3->setObjectName(QStringLiteral("lineEdit_subject_3"));

        horizontalLayout_6->addWidget(lineEdit_subject_3);

        lineEdit_sender_3 = new QLineEdit(layoutWidget);
        lineEdit_sender_3->setObjectName(QStringLiteral("lineEdit_sender_3"));

        horizontalLayout_6->addWidget(lineEdit_sender_3);

        lineEdit_receiver_3 = new QLineEdit(layoutWidget);
        lineEdit_receiver_3->setObjectName(QStringLiteral("lineEdit_receiver_3"));

        horizontalLayout_6->addWidget(lineEdit_receiver_3);

        pushButton_open_3 = new QPushButton(layoutWidget);
        pushButton_open_3->setObjectName(QStringLiteral("pushButton_open_3"));

        horizontalLayout_6->addWidget(pushButton_open_3);

        pushButton_forward_3 = new QPushButton(layoutWidget);
        pushButton_forward_3->setObjectName(QStringLiteral("pushButton_forward_3"));

        horizontalLayout_6->addWidget(pushButton_forward_3);

        pushButton_delete_3 = new QPushButton(layoutWidget);
        pushButton_delete_3->setObjectName(QStringLiteral("pushButton_delete_3"));

        horizontalLayout_6->addWidget(pushButton_delete_3);

        checkBox_read_3 = new QCheckBox(layoutWidget);
        checkBox_read_3->setObjectName(QStringLiteral("checkBox_read_3"));

        horizontalLayout_6->addWidget(checkBox_read_3);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(0);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        lineEdit_subject_4 = new QLineEdit(layoutWidget);
        lineEdit_subject_4->setObjectName(QStringLiteral("lineEdit_subject_4"));

        horizontalLayout_7->addWidget(lineEdit_subject_4);

        lineEdit_sender_4 = new QLineEdit(layoutWidget);
        lineEdit_sender_4->setObjectName(QStringLiteral("lineEdit_sender_4"));

        horizontalLayout_7->addWidget(lineEdit_sender_4);

        lineEdit_receiver_4 = new QLineEdit(layoutWidget);
        lineEdit_receiver_4->setObjectName(QStringLiteral("lineEdit_receiver_4"));

        horizontalLayout_7->addWidget(lineEdit_receiver_4);

        pushButton_open_4 = new QPushButton(layoutWidget);
        pushButton_open_4->setObjectName(QStringLiteral("pushButton_open_4"));

        horizontalLayout_7->addWidget(pushButton_open_4);

        pushButton_forward_4 = new QPushButton(layoutWidget);
        pushButton_forward_4->setObjectName(QStringLiteral("pushButton_forward_4"));

        horizontalLayout_7->addWidget(pushButton_forward_4);

        pushButton_delete_4 = new QPushButton(layoutWidget);
        pushButton_delete_4->setObjectName(QStringLiteral("pushButton_delete_4"));

        horizontalLayout_7->addWidget(pushButton_delete_4);

        checkBox_read_4 = new QCheckBox(layoutWidget);
        checkBox_read_4->setObjectName(QStringLiteral("checkBox_read_4"));

        horizontalLayout_7->addWidget(checkBox_read_4);


        verticalLayout->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(0);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        lineEdit_subject_5 = new QLineEdit(layoutWidget);
        lineEdit_subject_5->setObjectName(QStringLiteral("lineEdit_subject_5"));

        horizontalLayout_8->addWidget(lineEdit_subject_5);

        lineEdit_sender_5 = new QLineEdit(layoutWidget);
        lineEdit_sender_5->setObjectName(QStringLiteral("lineEdit_sender_5"));

        horizontalLayout_8->addWidget(lineEdit_sender_5);

        lineEdit_receiver_5 = new QLineEdit(layoutWidget);
        lineEdit_receiver_5->setObjectName(QStringLiteral("lineEdit_receiver_5"));

        horizontalLayout_8->addWidget(lineEdit_receiver_5);

        pushButton_open_5 = new QPushButton(layoutWidget);
        pushButton_open_5->setObjectName(QStringLiteral("pushButton_open_5"));

        horizontalLayout_8->addWidget(pushButton_open_5);

        pushButton_forward_5 = new QPushButton(layoutWidget);
        pushButton_forward_5->setObjectName(QStringLiteral("pushButton_forward_5"));

        horizontalLayout_8->addWidget(pushButton_forward_5);

        pushButton_delete_5 = new QPushButton(layoutWidget);
        pushButton_delete_5->setObjectName(QStringLiteral("pushButton_delete_5"));

        horizontalLayout_8->addWidget(pushButton_delete_5);

        checkBox_read_5 = new QCheckBox(layoutWidget);
        checkBox_read_5->setObjectName(QStringLiteral("checkBox_read_5"));

        horizontalLayout_8->addWidget(checkBox_read_5);


        verticalLayout->addLayout(horizontalLayout_8);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(0);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        lineEdit_subject_6 = new QLineEdit(layoutWidget);
        lineEdit_subject_6->setObjectName(QStringLiteral("lineEdit_subject_6"));

        horizontalLayout_11->addWidget(lineEdit_subject_6);

        lineEdit_sender_6 = new QLineEdit(layoutWidget);
        lineEdit_sender_6->setObjectName(QStringLiteral("lineEdit_sender_6"));

        horizontalLayout_11->addWidget(lineEdit_sender_6);

        lineEdit_receiver_6 = new QLineEdit(layoutWidget);
        lineEdit_receiver_6->setObjectName(QStringLiteral("lineEdit_receiver_6"));

        horizontalLayout_11->addWidget(lineEdit_receiver_6);

        pushButton_open_6 = new QPushButton(layoutWidget);
        pushButton_open_6->setObjectName(QStringLiteral("pushButton_open_6"));

        horizontalLayout_11->addWidget(pushButton_open_6);

        pushButton_forward_6 = new QPushButton(layoutWidget);
        pushButton_forward_6->setObjectName(QStringLiteral("pushButton_forward_6"));

        horizontalLayout_11->addWidget(pushButton_forward_6);

        pushButton_delete_6 = new QPushButton(layoutWidget);
        pushButton_delete_6->setObjectName(QStringLiteral("pushButton_delete_6"));

        horizontalLayout_11->addWidget(pushButton_delete_6);

        checkBox_read_6 = new QCheckBox(layoutWidget);
        checkBox_read_6->setObjectName(QStringLiteral("checkBox_read_6"));

        horizontalLayout_11->addWidget(checkBox_read_6);


        verticalLayout->addLayout(horizontalLayout_11);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(0);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        lineEdit_subject_7 = new QLineEdit(layoutWidget);
        lineEdit_subject_7->setObjectName(QStringLiteral("lineEdit_subject_7"));

        horizontalLayout_9->addWidget(lineEdit_subject_7);

        lineEdit_sender_7 = new QLineEdit(layoutWidget);
        lineEdit_sender_7->setObjectName(QStringLiteral("lineEdit_sender_7"));

        horizontalLayout_9->addWidget(lineEdit_sender_7);

        lineEdit_receiver_7 = new QLineEdit(layoutWidget);
        lineEdit_receiver_7->setObjectName(QStringLiteral("lineEdit_receiver_7"));

        horizontalLayout_9->addWidget(lineEdit_receiver_7);

        pushButton_open_7 = new QPushButton(layoutWidget);
        pushButton_open_7->setObjectName(QStringLiteral("pushButton_open_7"));

        horizontalLayout_9->addWidget(pushButton_open_7);

        pushButton_forward_7 = new QPushButton(layoutWidget);
        pushButton_forward_7->setObjectName(QStringLiteral("pushButton_forward_7"));

        horizontalLayout_9->addWidget(pushButton_forward_7);

        pushButton_delete_7 = new QPushButton(layoutWidget);
        pushButton_delete_7->setObjectName(QStringLiteral("pushButton_delete_7"));

        horizontalLayout_9->addWidget(pushButton_delete_7);

        checkBox_read_7 = new QCheckBox(layoutWidget);
        checkBox_read_7->setObjectName(QStringLiteral("checkBox_read_7"));

        horizontalLayout_9->addWidget(checkBox_read_7);


        verticalLayout->addLayout(horizontalLayout_9);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(0);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        lineEdit_subject_10 = new QLineEdit(layoutWidget);
        lineEdit_subject_10->setObjectName(QStringLiteral("lineEdit_subject_10"));

        horizontalLayout_14->addWidget(lineEdit_subject_10);

        lineEdit_sender_10 = new QLineEdit(layoutWidget);
        lineEdit_sender_10->setObjectName(QStringLiteral("lineEdit_sender_10"));

        horizontalLayout_14->addWidget(lineEdit_sender_10);

        lineEdit_receiver_10 = new QLineEdit(layoutWidget);
        lineEdit_receiver_10->setObjectName(QStringLiteral("lineEdit_receiver_10"));

        horizontalLayout_14->addWidget(lineEdit_receiver_10);

        pushButton_open_10 = new QPushButton(layoutWidget);
        pushButton_open_10->setObjectName(QStringLiteral("pushButton_open_10"));

        horizontalLayout_14->addWidget(pushButton_open_10);

        pushButton_forward_10 = new QPushButton(layoutWidget);
        pushButton_forward_10->setObjectName(QStringLiteral("pushButton_forward_10"));

        horizontalLayout_14->addWidget(pushButton_forward_10);

        pushButton_delete_10 = new QPushButton(layoutWidget);
        pushButton_delete_10->setObjectName(QStringLiteral("pushButton_delete_10"));

        horizontalLayout_14->addWidget(pushButton_delete_10);

        checkBox_read_8 = new QCheckBox(layoutWidget);
        checkBox_read_8->setObjectName(QStringLiteral("checkBox_read_8"));

        horizontalLayout_14->addWidget(checkBox_read_8);


        verticalLayout->addLayout(horizontalLayout_14);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(0);
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        lineEdit_subject_12 = new QLineEdit(layoutWidget);
        lineEdit_subject_12->setObjectName(QStringLiteral("lineEdit_subject_12"));

        horizontalLayout_16->addWidget(lineEdit_subject_12);

        lineEdit_sender_12 = new QLineEdit(layoutWidget);
        lineEdit_sender_12->setObjectName(QStringLiteral("lineEdit_sender_12"));

        horizontalLayout_16->addWidget(lineEdit_sender_12);

        lineEdit_receiver_12 = new QLineEdit(layoutWidget);
        lineEdit_receiver_12->setObjectName(QStringLiteral("lineEdit_receiver_12"));

        horizontalLayout_16->addWidget(lineEdit_receiver_12);

        pushButton_open_12 = new QPushButton(layoutWidget);
        pushButton_open_12->setObjectName(QStringLiteral("pushButton_open_12"));

        horizontalLayout_16->addWidget(pushButton_open_12);

        pushButton_forward_12 = new QPushButton(layoutWidget);
        pushButton_forward_12->setObjectName(QStringLiteral("pushButton_forward_12"));

        horizontalLayout_16->addWidget(pushButton_forward_12);

        pushButton_delete_12 = new QPushButton(layoutWidget);
        pushButton_delete_12->setObjectName(QStringLiteral("pushButton_delete_12"));

        horizontalLayout_16->addWidget(pushButton_delete_12);

        checkBox_read_9 = new QCheckBox(layoutWidget);
        checkBox_read_9->setObjectName(QStringLiteral("checkBox_read_9"));

        horizontalLayout_16->addWidget(checkBox_read_9);


        verticalLayout->addLayout(horizontalLayout_16);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(0);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        lineEdit_subject_13 = new QLineEdit(layoutWidget);
        lineEdit_subject_13->setObjectName(QStringLiteral("lineEdit_subject_13"));

        horizontalLayout_17->addWidget(lineEdit_subject_13);

        lineEdit_sender_13 = new QLineEdit(layoutWidget);
        lineEdit_sender_13->setObjectName(QStringLiteral("lineEdit_sender_13"));

        horizontalLayout_17->addWidget(lineEdit_sender_13);

        lineEdit_receiver_13 = new QLineEdit(layoutWidget);
        lineEdit_receiver_13->setObjectName(QStringLiteral("lineEdit_receiver_13"));

        horizontalLayout_17->addWidget(lineEdit_receiver_13);

        pushButton_open_13 = new QPushButton(layoutWidget);
        pushButton_open_13->setObjectName(QStringLiteral("pushButton_open_13"));

        horizontalLayout_17->addWidget(pushButton_open_13);

        pushButton_forward_13 = new QPushButton(layoutWidget);
        pushButton_forward_13->setObjectName(QStringLiteral("pushButton_forward_13"));

        horizontalLayout_17->addWidget(pushButton_forward_13);

        pushButton_delete_13 = new QPushButton(layoutWidget);
        pushButton_delete_13->setObjectName(QStringLiteral("pushButton_delete_13"));

        horizontalLayout_17->addWidget(pushButton_delete_13);

        checkBox_read_10 = new QCheckBox(layoutWidget);
        checkBox_read_10->setObjectName(QStringLiteral("checkBox_read_10"));

        horizontalLayout_17->addWidget(checkBox_read_10);


        verticalLayout->addLayout(horizontalLayout_17);

        label_mail_amount = new QLabel(groupBox_2);
        label_mail_amount->setObjectName(QStringLiteral("label_mail_amount"));
        label_mail_amount->setGeometry(QRect(20, 410, 351, 17));
        label_mails = new QLabel(groupBox_2);
        label_mails->setObjectName(QStringLiteral("label_mails"));
        label_mails->setGeometry(QRect(20, 390, 251, 17));
        layoutWidget1 = new QWidget(groupBox_2);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(480, 400, 168, 27));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_prevpage = new QPushButton(layoutWidget1);
        pushButton_prevpage->setObjectName(QStringLiteral("pushButton_prevpage"));

        horizontalLayout_3->addWidget(pushButton_prevpage);

        pushButton_nextpage = new QPushButton(layoutWidget1);
        pushButton_nextpage->setObjectName(QStringLiteral("pushButton_nextpage"));

        horizontalLayout_3->addWidget(pushButton_nextpage);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        groupBox = new QGroupBox(page_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(100, 30, 481, 431));
        pushButton_sendmail = new QPushButton(groupBox);
        pushButton_sendmail->setObjectName(QStringLiteral("pushButton_sendmail"));
        pushButton_sendmail->setGeometry(QRect(360, 400, 89, 25));
        plainTextEdit = new QPlainTextEdit(groupBox);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(30, 120, 421, 271));
        layoutWidget2 = new QWidget(groupBox);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(30, 40, 421, 27));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget2);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_2->addWidget(label);

        lineEdit_sendto = new QLineEdit(layoutWidget2);
        lineEdit_sendto->setObjectName(QStringLiteral("lineEdit_sendto"));

        horizontalLayout_2->addWidget(lineEdit_sendto);

        layoutWidget_2 = new QWidget(groupBox);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(30, 80, 421, 27));
        horizontalLayout = new QHBoxLayout(layoutWidget_2);
        horizontalLayout->setSpacing(10);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEdit_subject = new QLineEdit(layoutWidget_2);
        lineEdit_subject->setObjectName(QStringLiteral("lineEdit_subject"));

        horizontalLayout->addWidget(lineEdit_subject);

        stackedWidget->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        groupBox_3 = new QGroupBox(page_3);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(100, 30, 481, 431));
        plainTextEdit_2 = new QPlainTextEdit(groupBox_3);
        plainTextEdit_2->setObjectName(QStringLiteral("plainTextEdit_2"));
        plainTextEdit_2->setGeometry(QRect(30, 120, 421, 271));
        layoutWidget_7 = new QWidget(groupBox_3);
        layoutWidget_7->setObjectName(QStringLiteral("layoutWidget_7"));
        layoutWidget_7->setGeometry(QRect(30, 40, 421, 27));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget_7);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget_7);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_4->addWidget(label_3);

        lineEdit_sendto_2 = new QLineEdit(layoutWidget_7);
        lineEdit_sendto_2->setObjectName(QStringLiteral("lineEdit_sendto_2"));

        horizontalLayout_4->addWidget(lineEdit_sendto_2);

        layoutWidget_8 = new QWidget(groupBox_3);
        layoutWidget_8->setObjectName(QStringLiteral("layoutWidget_8"));
        layoutWidget_8->setGeometry(QRect(30, 80, 421, 27));
        horizontalLayout_18 = new QHBoxLayout(layoutWidget_8);
        horizontalLayout_18->setSpacing(26);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        horizontalLayout_18->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(layoutWidget_8);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_18->addWidget(label_4);

        lineEdit_subject_14 = new QLineEdit(layoutWidget_8);
        lineEdit_subject_14->setObjectName(QStringLiteral("lineEdit_subject_14"));

        horizontalLayout_18->addWidget(lineEdit_subject_14);

        pushButton = new QPushButton(groupBox_3);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(360, 400, 89, 25));
        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QStringLiteral("page_4"));
        groupBox_4 = new QGroupBox(page_4);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(80, 10, 481, 431));
        plainTextEdit_3 = new QPlainTextEdit(groupBox_4);
        plainTextEdit_3->setObjectName(QStringLiteral("plainTextEdit_3"));
        plainTextEdit_3->setGeometry(QRect(30, 120, 421, 271));
        layoutWidget_9 = new QWidget(groupBox_4);
        layoutWidget_9->setObjectName(QStringLiteral("layoutWidget_9"));
        layoutWidget_9->setGeometry(QRect(30, 40, 421, 27));
        horizontalLayout_12 = new QHBoxLayout(layoutWidget_9);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget_9);
        label_5->setObjectName(QStringLiteral("label_5"));

        horizontalLayout_12->addWidget(label_5);

        lineEdit_3 = new QLineEdit(layoutWidget_9);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        horizontalLayout_12->addWidget(lineEdit_3);

        layoutWidget_10 = new QWidget(groupBox_4);
        layoutWidget_10->setObjectName(QStringLiteral("layoutWidget_10"));
        layoutWidget_10->setGeometry(QRect(30, 80, 421, 27));
        horizontalLayout_19 = new QHBoxLayout(layoutWidget_10);
        horizontalLayout_19->setSpacing(26);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        horizontalLayout_19->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(layoutWidget_10);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_19->addWidget(label_9);

        lineEdit_4 = new QLineEdit(layoutWidget_10);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));

        horizontalLayout_19->addWidget(lineEdit_4);

        pushButton_2 = new QPushButton(groupBox_4);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(360, 400, 89, 25));
        stackedWidget->addWidget(page_4);
        Inboxwindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Inboxwindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 778, 22));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        Inboxwindow->setMenuBar(menubar);
        statusbar = new QStatusBar(Inboxwindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Inboxwindow->setStatusBar(statusbar);
        toolBar = new QToolBar(Inboxwindow);
        toolBar->setObjectName(QStringLiteral("toolBar"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(toolBar->sizePolicy().hasHeightForWidth());
        toolBar->setSizePolicy(sizePolicy);
        toolBar->setLayoutDirection(Qt::LeftToRight);
        toolBar->setMovable(false);
        toolBar->setOrientation(Qt::Vertical);
        toolBar->setToolButtonStyle(Qt::ToolButtonIconOnly);
        Inboxwindow->addToolBar(Qt::LeftToolBarArea, toolBar);

        menubar->addAction(menuFile->menuAction());
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addSeparator();
        menuFile->addAction(actionExit);
        toolBar->addAction(actionNew);
        toolBar->addAction(actionOpen);
        toolBar->addAction(actionExit);

        retranslateUi(Inboxwindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Inboxwindow);
    } // setupUi

    void retranslateUi(QMainWindow *Inboxwindow)
    {
        Inboxwindow->setWindowTitle(QApplication::translate("Inboxwindow", "Eggbox", Q_NULLPTR));
        actionNew->setText(QApplication::translate("Inboxwindow", "New", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        actionExit->setText(QApplication::translate("Inboxwindow", "Logout", Q_NULLPTR));
        groupBox_2->setTitle(QString());
        label_6->setText(QApplication::translate("Inboxwindow", "Subject", Q_NULLPTR));
        label_7->setText(QApplication::translate("Inboxwindow", "Sender", Q_NULLPTR));
        label_8->setText(QApplication::translate("Inboxwindow", "Reciever", Q_NULLPTR));
        pushButton_open->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_2->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_2->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_2->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_2->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_3->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_3->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_3->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_3->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_4->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_4->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_4->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_4->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_5->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_5->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_5->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_5->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_6->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_6->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_6->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_6->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_7->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_7->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_7->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_7->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_10->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_10->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_10->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_8->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_12->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_12->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_12->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_9->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        pushButton_open_13->setText(QApplication::translate("Inboxwindow", "Open", Q_NULLPTR));
        pushButton_forward_13->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        pushButton_delete_13->setText(QApplication::translate("Inboxwindow", "Delete", Q_NULLPTR));
        checkBox_read_10->setText(QApplication::translate("Inboxwindow", "Read", Q_NULLPTR));
        label_mail_amount->setText(QApplication::translate("Inboxwindow", "Shown mails are from 1 to 10", Q_NULLPTR));
        label_mails->setText(QString());
        pushButton_prevpage->setText(QApplication::translate("Inboxwindow", "Prev Page", Q_NULLPTR));
        pushButton_nextpage->setText(QApplication::translate("Inboxwindow", "Next Page", Q_NULLPTR));
        groupBox->setTitle(QString());
        pushButton_sendmail->setText(QApplication::translate("Inboxwindow", "Send", Q_NULLPTR));
        plainTextEdit->setPlaceholderText(QApplication::translate("Inboxwindow", "Write somehting here", Q_NULLPTR));
        label->setText(QApplication::translate("Inboxwindow", "Send To:", Q_NULLPTR));
        lineEdit_sendto->setPlaceholderText(QApplication::translate("Inboxwindow", "Add user(s) you want to send to!", Q_NULLPTR));
        label_2->setText(QApplication::translate("Inboxwindow", "Subject:", Q_NULLPTR));
        lineEdit_subject->setText(QString());
        lineEdit_subject->setPlaceholderText(QApplication::translate("Inboxwindow", "Write a short summary ", Q_NULLPTR));
        groupBox_3->setTitle(QString());
        plainTextEdit_2->setPlaceholderText(QString());
        label_3->setText(QApplication::translate("Inboxwindow", "Sender:      ", Q_NULLPTR));
        lineEdit_sendto_2->setPlaceholderText(QString());
        label_4->setText(QApplication::translate("Inboxwindow", "Subject:", Q_NULLPTR));
        lineEdit_subject_14->setText(QString());
        lineEdit_subject_14->setPlaceholderText(QString());
        pushButton->setText(QApplication::translate("Inboxwindow", "Reply", Q_NULLPTR));
        groupBox_4->setTitle(QString());
        plainTextEdit_3->setPlaceholderText(QString());
        label_5->setText(QApplication::translate("Inboxwindow", "Forward to:", Q_NULLPTR));
        lineEdit_3->setPlaceholderText(QString());
        label_9->setText(QApplication::translate("Inboxwindow", "Subject :", Q_NULLPTR));
        lineEdit_4->setText(QString());
        lineEdit_4->setPlaceholderText(QString());
        pushButton_2->setText(QApplication::translate("Inboxwindow", "Forward", Q_NULLPTR));
        menuFile->setTitle(QApplication::translate("Inboxwindow", "File", Q_NULLPTR));
        toolBar->setWindowTitle(QApplication::translate("Inboxwindow", "toolBar", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Inboxwindow: public Ui_Inboxwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INBOXWINDOW_H
