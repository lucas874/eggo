/****************************************************************************
** Meta object code from reading C++ file 'inboxwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "inboxwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'inboxwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Inboxwindow_t {
    QByteArrayData data[50];
    char stringdata0[1415];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Inboxwindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Inboxwindow_t qt_meta_stringdata_Inboxwindow = {
    {
QT_MOC_LITERAL(0, 0, 11), // "Inboxwindow"
QT_MOC_LITERAL(1, 12, 22), // "on_actionNew_triggered"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 23), // "on_actionExit_triggered"
QT_MOC_LITERAL(4, 60, 30), // "on_pushButton_sendmail_clicked"
QT_MOC_LITERAL(5, 91, 30), // "on_pushButton_nextpage_clicked"
QT_MOC_LITERAL(6, 122, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(7, 146, 28), // "on_pushButton_delete_clicked"
QT_MOC_LITERAL(8, 175, 30), // "on_pushButton_prevpage_clicked"
QT_MOC_LITERAL(9, 206, 24), // "on_checkBox_read_clicked"
QT_MOC_LITERAL(10, 231, 26), // "on_pushButton_open_clicked"
QT_MOC_LITERAL(11, 258, 28), // "on_pushButton_open_2_clicked"
QT_MOC_LITERAL(12, 287, 28), // "on_pushButton_open_3_clicked"
QT_MOC_LITERAL(13, 316, 28), // "on_pushButton_open_4_clicked"
QT_MOC_LITERAL(14, 345, 28), // "on_pushButton_open_5_clicked"
QT_MOC_LITERAL(15, 374, 28), // "on_pushButton_open_6_clicked"
QT_MOC_LITERAL(16, 403, 28), // "on_pushButton_open_7_clicked"
QT_MOC_LITERAL(17, 432, 29), // "on_pushButton_open_10_clicked"
QT_MOC_LITERAL(18, 462, 29), // "on_pushButton_open_12_clicked"
QT_MOC_LITERAL(19, 492, 29), // "on_pushButton_open_13_clicked"
QT_MOC_LITERAL(20, 522, 27), // "on_checkBox_read_10_clicked"
QT_MOC_LITERAL(21, 550, 26), // "on_checkBox_read_2_clicked"
QT_MOC_LITERAL(22, 577, 26), // "on_checkBox_read_3_clicked"
QT_MOC_LITERAL(23, 604, 26), // "on_checkBox_read_4_clicked"
QT_MOC_LITERAL(24, 631, 26), // "on_checkBox_read_5_clicked"
QT_MOC_LITERAL(25, 658, 26), // "on_checkBox_read_6_clicked"
QT_MOC_LITERAL(26, 685, 26), // "on_checkBox_read_7_clicked"
QT_MOC_LITERAL(27, 712, 26), // "on_checkBox_read_8_clicked"
QT_MOC_LITERAL(28, 739, 26), // "on_checkBox_read_9_clicked"
QT_MOC_LITERAL(29, 766, 29), // "on_pushButton_forward_clicked"
QT_MOC_LITERAL(30, 796, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(31, 820, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(32, 842, 31), // "on_pushButton_forward_2_clicked"
QT_MOC_LITERAL(33, 874, 31), // "on_pushButton_forward_3_clicked"
QT_MOC_LITERAL(34, 906, 31), // "on_pushButton_forward_4_clicked"
QT_MOC_LITERAL(35, 938, 31), // "on_pushButton_forward_5_clicked"
QT_MOC_LITERAL(36, 970, 31), // "on_pushButton_forward_6_clicked"
QT_MOC_LITERAL(37, 1002, 31), // "on_pushButton_forward_7_clicked"
QT_MOC_LITERAL(38, 1034, 32), // "on_pushButton_forward_10_clicked"
QT_MOC_LITERAL(39, 1067, 32), // "on_pushButton_forward_12_clicked"
QT_MOC_LITERAL(40, 1100, 32), // "on_pushButton_forward_13_clicked"
QT_MOC_LITERAL(41, 1133, 30), // "on_pushButton_delete_2_clicked"
QT_MOC_LITERAL(42, 1164, 30), // "on_pushButton_delete_3_clicked"
QT_MOC_LITERAL(43, 1195, 30), // "on_pushButton_delete_4_clicked"
QT_MOC_LITERAL(44, 1226, 30), // "on_pushButton_delete_5_clicked"
QT_MOC_LITERAL(45, 1257, 30), // "on_pushButton_delete_6_clicked"
QT_MOC_LITERAL(46, 1288, 30), // "on_pushButton_delete_7_clicked"
QT_MOC_LITERAL(47, 1319, 31), // "on_pushButton_delete_10_clicked"
QT_MOC_LITERAL(48, 1351, 31), // "on_pushButton_delete_12_clicked"
QT_MOC_LITERAL(49, 1383, 31) // "on_pushButton_delete_13_clicked"

    },
    "Inboxwindow\0on_actionNew_triggered\0\0"
    "on_actionExit_triggered\0"
    "on_pushButton_sendmail_clicked\0"
    "on_pushButton_nextpage_clicked\0"
    "on_actionOpen_triggered\0"
    "on_pushButton_delete_clicked\0"
    "on_pushButton_prevpage_clicked\0"
    "on_checkBox_read_clicked\0"
    "on_pushButton_open_clicked\0"
    "on_pushButton_open_2_clicked\0"
    "on_pushButton_open_3_clicked\0"
    "on_pushButton_open_4_clicked\0"
    "on_pushButton_open_5_clicked\0"
    "on_pushButton_open_6_clicked\0"
    "on_pushButton_open_7_clicked\0"
    "on_pushButton_open_10_clicked\0"
    "on_pushButton_open_12_clicked\0"
    "on_pushButton_open_13_clicked\0"
    "on_checkBox_read_10_clicked\0"
    "on_checkBox_read_2_clicked\0"
    "on_checkBox_read_3_clicked\0"
    "on_checkBox_read_4_clicked\0"
    "on_checkBox_read_5_clicked\0"
    "on_checkBox_read_6_clicked\0"
    "on_checkBox_read_7_clicked\0"
    "on_checkBox_read_8_clicked\0"
    "on_checkBox_read_9_clicked\0"
    "on_pushButton_forward_clicked\0"
    "on_pushButton_2_clicked\0on_pushButton_clicked\0"
    "on_pushButton_forward_2_clicked\0"
    "on_pushButton_forward_3_clicked\0"
    "on_pushButton_forward_4_clicked\0"
    "on_pushButton_forward_5_clicked\0"
    "on_pushButton_forward_6_clicked\0"
    "on_pushButton_forward_7_clicked\0"
    "on_pushButton_forward_10_clicked\0"
    "on_pushButton_forward_12_clicked\0"
    "on_pushButton_forward_13_clicked\0"
    "on_pushButton_delete_2_clicked\0"
    "on_pushButton_delete_3_clicked\0"
    "on_pushButton_delete_4_clicked\0"
    "on_pushButton_delete_5_clicked\0"
    "on_pushButton_delete_6_clicked\0"
    "on_pushButton_delete_7_clicked\0"
    "on_pushButton_delete_10_clicked\0"
    "on_pushButton_delete_12_clicked\0"
    "on_pushButton_delete_13_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Inboxwindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      48,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  254,    2, 0x08 /* Private */,
       3,    0,  255,    2, 0x08 /* Private */,
       4,    0,  256,    2, 0x08 /* Private */,
       5,    0,  257,    2, 0x08 /* Private */,
       6,    0,  258,    2, 0x08 /* Private */,
       7,    0,  259,    2, 0x08 /* Private */,
       8,    0,  260,    2, 0x08 /* Private */,
       9,    0,  261,    2, 0x08 /* Private */,
      10,    0,  262,    2, 0x08 /* Private */,
      11,    0,  263,    2, 0x08 /* Private */,
      12,    0,  264,    2, 0x08 /* Private */,
      13,    0,  265,    2, 0x08 /* Private */,
      14,    0,  266,    2, 0x08 /* Private */,
      15,    0,  267,    2, 0x08 /* Private */,
      16,    0,  268,    2, 0x08 /* Private */,
      17,    0,  269,    2, 0x08 /* Private */,
      18,    0,  270,    2, 0x08 /* Private */,
      19,    0,  271,    2, 0x08 /* Private */,
      20,    0,  272,    2, 0x08 /* Private */,
      21,    0,  273,    2, 0x08 /* Private */,
      22,    0,  274,    2, 0x08 /* Private */,
      23,    0,  275,    2, 0x08 /* Private */,
      24,    0,  276,    2, 0x08 /* Private */,
      25,    0,  277,    2, 0x08 /* Private */,
      26,    0,  278,    2, 0x08 /* Private */,
      27,    0,  279,    2, 0x08 /* Private */,
      28,    0,  280,    2, 0x08 /* Private */,
      29,    0,  281,    2, 0x08 /* Private */,
      30,    0,  282,    2, 0x08 /* Private */,
      31,    0,  283,    2, 0x08 /* Private */,
      32,    0,  284,    2, 0x08 /* Private */,
      33,    0,  285,    2, 0x08 /* Private */,
      34,    0,  286,    2, 0x08 /* Private */,
      35,    0,  287,    2, 0x08 /* Private */,
      36,    0,  288,    2, 0x08 /* Private */,
      37,    0,  289,    2, 0x08 /* Private */,
      38,    0,  290,    2, 0x08 /* Private */,
      39,    0,  291,    2, 0x08 /* Private */,
      40,    0,  292,    2, 0x08 /* Private */,
      41,    0,  293,    2, 0x08 /* Private */,
      42,    0,  294,    2, 0x08 /* Private */,
      43,    0,  295,    2, 0x08 /* Private */,
      44,    0,  296,    2, 0x08 /* Private */,
      45,    0,  297,    2, 0x08 /* Private */,
      46,    0,  298,    2, 0x08 /* Private */,
      47,    0,  299,    2, 0x08 /* Private */,
      48,    0,  300,    2, 0x08 /* Private */,
      49,    0,  301,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Inboxwindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Inboxwindow *_t = static_cast<Inboxwindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_actionNew_triggered(); break;
        case 1: _t->on_actionExit_triggered(); break;
        case 2: _t->on_pushButton_sendmail_clicked(); break;
        case 3: _t->on_pushButton_nextpage_clicked(); break;
        case 4: _t->on_actionOpen_triggered(); break;
        case 5: _t->on_pushButton_delete_clicked(); break;
        case 6: _t->on_pushButton_prevpage_clicked(); break;
        case 7: _t->on_checkBox_read_clicked(); break;
        case 8: _t->on_pushButton_open_clicked(); break;
        case 9: _t->on_pushButton_open_2_clicked(); break;
        case 10: _t->on_pushButton_open_3_clicked(); break;
        case 11: _t->on_pushButton_open_4_clicked(); break;
        case 12: _t->on_pushButton_open_5_clicked(); break;
        case 13: _t->on_pushButton_open_6_clicked(); break;
        case 14: _t->on_pushButton_open_7_clicked(); break;
        case 15: _t->on_pushButton_open_10_clicked(); break;
        case 16: _t->on_pushButton_open_12_clicked(); break;
        case 17: _t->on_pushButton_open_13_clicked(); break;
        case 18: _t->on_checkBox_read_10_clicked(); break;
        case 19: _t->on_checkBox_read_2_clicked(); break;
        case 20: _t->on_checkBox_read_3_clicked(); break;
        case 21: _t->on_checkBox_read_4_clicked(); break;
        case 22: _t->on_checkBox_read_5_clicked(); break;
        case 23: _t->on_checkBox_read_6_clicked(); break;
        case 24: _t->on_checkBox_read_7_clicked(); break;
        case 25: _t->on_checkBox_read_8_clicked(); break;
        case 26: _t->on_checkBox_read_9_clicked(); break;
        case 27: _t->on_pushButton_forward_clicked(); break;
        case 28: _t->on_pushButton_2_clicked(); break;
        case 29: _t->on_pushButton_clicked(); break;
        case 30: _t->on_pushButton_forward_2_clicked(); break;
        case 31: _t->on_pushButton_forward_3_clicked(); break;
        case 32: _t->on_pushButton_forward_4_clicked(); break;
        case 33: _t->on_pushButton_forward_5_clicked(); break;
        case 34: _t->on_pushButton_forward_6_clicked(); break;
        case 35: _t->on_pushButton_forward_7_clicked(); break;
        case 36: _t->on_pushButton_forward_10_clicked(); break;
        case 37: _t->on_pushButton_forward_12_clicked(); break;
        case 38: _t->on_pushButton_forward_13_clicked(); break;
        case 39: _t->on_pushButton_delete_2_clicked(); break;
        case 40: _t->on_pushButton_delete_3_clicked(); break;
        case 41: _t->on_pushButton_delete_4_clicked(); break;
        case 42: _t->on_pushButton_delete_5_clicked(); break;
        case 43: _t->on_pushButton_delete_6_clicked(); break;
        case 44: _t->on_pushButton_delete_7_clicked(); break;
        case 45: _t->on_pushButton_delete_10_clicked(); break;
        case 46: _t->on_pushButton_delete_12_clicked(); break;
        case 47: _t->on_pushButton_delete_13_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject Inboxwindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Inboxwindow.data,
      qt_meta_data_Inboxwindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Inboxwindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Inboxwindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Inboxwindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Inboxwindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 48)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 48;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 48)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 48;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
