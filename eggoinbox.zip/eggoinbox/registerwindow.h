#ifndef REGISTERWINDOW_H
#define REGISTERWINDOW_H

#include <QDialog>
#include <QMessageBox>
#include <stdlib.h>
#include <zmq.hpp>
#include <QTextStream>

namespace Ui {
class registerwindow;
}

class registerwindow : public QDialog
{
    Q_OBJECT

public:
    explicit registerwindow(QWidget *parent = 0);
    ~registerwindow();

private:
    std::string msg(std::string request,zmq::socket_t *socket);
    int registercheck(std::string n,std::string p1,std::string p2);
    Ui::registerwindow *ui;
    zmq::context_t context{1};
    zmq::socket_t *socket;

private slots:
    void on_pushButton_register2_clicked();

};

#endif // REGISTER_H
