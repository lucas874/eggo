#include "loginwindow.h"
#include "ui_loginwindow.h"

loginwindow::loginwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::loginwindow)
{
    ui->setupUi(this);
    QPixmap pix("/home/turtlebox/Desktop/qt-creator_/eggoinbox/eggo.png");
    int w = ui->label_pic->width();
    int h = ui->label_pic->height();
    ui->label_pic->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
}

loginwindow::~loginwindow()
{
    delete ui;
}

void loginwindow::openinboxwindow(std::string name,std::string pass){
    theinboxwindow = new Inboxwindow;
    theinboxwindow->currentUser = name;
    theinboxwindow->currentpass = pass;

    std::string t_text = (theinboxwindow->currentUser + "'s " + "Eggbox");
    QString userbox = QString::fromStdString(t_text);
    theinboxwindow->QWidget::setWindowTitle(userbox); //title of window
    qDebug() << "before setinbox";
    theinboxwindow->setinbox();
    qDebug() << "after setinbox";
    theinboxwindow->show();
}

void loginwindow::openregisterwindow(){
    theregisterwindow = new registerwindow;
    theregisterwindow->show();
}

int loginwindow::login(std::string name, std::string pass){

    // initialize the zmq context with a single IO thread
    zmq::context_t context{1};

    // construct a REQ (request) socket and connect to interface
    zmq::socket_t socket{context, zmq::socket_type::req};
    socket.connect("tcp://localhost:50001");
    zmq::message_t reply_name{};
    //establish a connection with the server
    std::string arr[4];
    std::string first = "";
    std::string fourth = "STAT";
    arr[0] = first;
    arr[1] = name;
    arr[2] = pass;
    arr[3] = fourth;
    std::string str;

    for(int i = 0; i < 4; i++){
        //send information to server
        socket.send(zmq::buffer(arr[i]), zmq::send_flags::none);
        socket.recv(reply_name, zmq::recv_flags::none);
        str = reply_name.to_string();
        if(str[0] == '-'){
            return -1;
        }
    }

    socket.send(zmq::buffer("QUIT"), zmq::send_flags::none);
    socket.recv(reply_name,zmq::recv_flags::none);
    return 0;

}

void loginwindow::on_pushButton_login_clicked()
{
    zmq::context_t context{1};

    // construct a REQ (request) socket and connect to interface
    zmq::socket_t socket{context, zmq::socket_type::req};
    socket.connect("tcp://localhost:50001");
    zmq::message_t reply_name{};
    //read name and password from UI textbox
    QString qname = ui->lineEdit_email->text();
    QString qpass = ui->lineEdit_password->text();
    //add strings according to POP
    std::string username = qname.toStdString();
    std::string password = qpass.toStdString();
    qname.prepend("USER ");
    qpass.prepend("PASS ");
    std::string name = qname.toStdString();
    std::string pass = qpass.toStdString();

    if(login(name,pass) == 0){
        this->hide();
        openinboxwindow(username, password);
    }
    //get mails

    socket.send(zmq::buffer("QUIT"), zmq::send_flags::none);
    socket.recv(reply_name,zmq::recv_flags::none);
}

void loginwindow::on_pushButton_register_clicked()
{
    //this->hide();
    openregisterwindow();
    //this->show();
}
