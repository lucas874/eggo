#include "registerwindow.h"
#include "ui_registerwindow.h"

registerwindow::registerwindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::registerwindow)
{
    socket = new zmq::socket_t{context, zmq::socket_type::req};
    ui->setupUi(this);
}

registerwindow::~registerwindow()
{
delete ui;
}

std::string registerwindow::msg(std::string request, zmq::socket_t *socket){

    zmq::message_t reply{};
    socket->send(zmq::buffer(request), zmq::send_flags::none);

    socket->recv(reply, zmq::recv_flags::none);

    std::string str = reply.to_string();

    return str;
}

int registerwindow::registercheck(std::string n,std::string p1,std::string p2){

    //username size check
    if (n.size() < 2){
        return -4;
    }

    //pasword size check
    if (p1.size() < 4){
        return -3;
    }

    //password match check
    if (p1.compare(p2) != 0){
        return -2;
    }

    //send msg to server
    std::string s1 = msg("ADDU " + n + " " + p1,socket);

    if(s1[0] == '+'){
        //user registered
        return 0;
    }
    if(s1[0] == '-'){
        //username already in use
        return -1;
    }
    return -1000;
}

void registerwindow::on_pushButton_register2_clicked()
{
    QString qname = ui->lineEdit_user->text();
    QString qpass = ui->lineEdit_pass1->text();
    QString qpass2 = ui->lineEdit_pass2->text();

    std::string name = qname.toStdString();
    std::string pass1 = qpass.toStdString();
    std::string pass2 = qpass2.toStdString();

    socket->connect("tcp://localhost:50002");

    msg("",socket);
    int t = registercheck(name,pass1,pass2);
    switch (t) {
    case 0:
        this->close();
        break;
    case -1:
        QMessageBox::information(this,"ERROR","user already exists");
        break;
    case -2:
        QMessageBox::information(this,"ERROR","password doesn't match");
        break;
    case -3:
        QMessageBox::information(this,"ERROR","password has to be 5 characters or longer");
        break;
    case -4:
        QMessageBox::information(this,"ERROR","Username has to be 2 characters or longer");
        break;
    default:
        break;
    }
    msg("QUIT", socket);
}
