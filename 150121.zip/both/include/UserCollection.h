#pragma once
#include <user.h>
#include <unordered_map>
#include <fstream>
class UserCollection {
public:
  UserCollection(){};
  void addUser(User*);
  void removeUser(User*);
  User* LookUp(std::string);
  void addMailToInbox(User*, PieceOfMail*);
  
private:
  std::unordered_map<std::string, User*> umap;
};
 
