#ifndef EVENT_H
#define EVENT_H

#include <iostream>

//	     0     1     2     3     4     5     6     7     8
enum Events {USER, PASS, STAT, LIST, RETR, DELE, NOOP, RSET, QUIT};

class Event {
	public:
		Event(enum Events e, std::string data);
		int getEventNo();
		int getStateNo();

		std::string getData();
	private:
		enum Events _event;
		std::string _data;
		int stateNumbers[8]; 
};

#endif
