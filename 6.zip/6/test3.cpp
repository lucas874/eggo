//#include "User.h"
//#include "PieceOfMail.h"
#include "UserCollection.h"


int main() {

  User a_user("Alice");
  User b_user("Bob");

  std::string data;

  data = "hej, hvordan går det med dig min ven?";
  

  PieceOfMail* p = a_user.newPieceOfMail();

  a_user.printpath();

  //std::cout << a_user.getlatest();

  p->append("test");
  p->append("mon /n/n det /n /t det virker");

  UserCollection *uc = new UserCollection;

  std::cout << uc->lookup("Alice");
  std::cout << uc->lookup("Bob");
  std::cout << uc->lookup("Karsten");
  

  //std::hash<std::string> h;

  //std::cout << h("Alice") % 7;
  //std::cout << h("Bob") % 7;
  
  
}
