#include "PieceOfMail.h"

PieceOfMail::PieceOfMail(std::string name) {
  _filename = name;
  content = new std::vector<std::string>;
}

void PieceOfMail::append(std::string data) {
  content->push_back(data);
}

std::vector<std::string>* PieceOfMail::getContent() {
  return content;
}


