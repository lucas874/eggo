#include "UserCollection.h"

UserCollection::UserCollection() {
  _users.resize(7);
}

void UserCollection::addUser(User* u) {
  _users.push_back(u);

}

void UserCollection::removeUser(User*) {

}

User* UserCollection::LookUp(std::string username) {
  return _users[_hash(username) % 7];
  
  }
		
int UserCollection::lookup(std::string username) {
  return _hash(username) % 7;
}
