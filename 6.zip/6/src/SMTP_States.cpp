#include "SMTP_States.h"
#include "SMTPConnection.h"

void SMTPInit::Action(SMTPConnection* sc) {
  //std::cout << "hello from Init Action()" << std::endl;
  sc->Reply(250);
}


void SMTPHelo::Action(SMTPConnection* sc) {
  std::cout << "hello from Helo Action()" << std::endl;
  std::string str = sc->getCurData().substr(5);
  sc->setSenderDomain(str);
  
  sc->Reply(250);
}


void SMTPMail::Action(SMTPConnection* sc) {
  std::cout << "hello from Mail Action()" << std::endl;
  std::string str = sc->getCurData();
  int i = 0;
  while(str[i] != '@')
    i++;

  std::string name;
  name = str.substr(0,i);

  sc->setSenderUsername(name);
  sc->Reply(250);
}


void SMTPRcpt::Action(SMTPConnection* sc) {
  std::cout << "hello from Rcpt Action()" << std::endl;
  std::string str = sc->getCurData();
  std::string domain;
  std::string name;

  int i = 0;
  while(str[i] != '@')
    i++;

  
  sc->rcptUsername = str.substr(0, i);
  sc->rcptDomain = str.substr(i+1);

  
  if(sc->rcptDomain.compare(DOMAIN_NAME) != 0) {
    sc->Reply(551);
    return;
  }
  else {
    sc->rcpt = sc->_uc->LookUp(name);
  }

  sc->curmail = new PieceOfMail("0.txt");
  
  sc->Reply(250);
}


void SMTPData::Action(SMTPConnection* sc) {
  std::cout << "hello from Data Action()" << std::endl;
  sc->Reply(354);

  std::string str = sc->getTextLine();
  while (str.compare(END_DATA) != 0) {
    sc->curmail->append(str);
    str = sc->getTextLine();
  }
    
  
}

void SMTPRset::Action(SMTPConnection* sc) {
  std::cout << "hello from Rset Action()" << std::endl;
  sc->Reply(250);
}


void SMTPQuit::Action(SMTPConnection* sc) {
  std::cout << "hello from Quit Action()" << std::endl;
  sc->Reply(221);
}
