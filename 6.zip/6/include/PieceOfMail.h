#ifndef _PIECEOFMAIL_H_
#define _PIECEOFMAIL_H_

#include <vector>
#include <string>

class PieceOfMail {
 private:
  std::string _filename;
  // Complete piece of mail is stored on heap as an intermediate state
  std::vector<std::string>* content;
 public:
  PieceOfMail(std::string name);
  void append(std::string data);
  std::vector<std::string>* getContent();
};


#endif
