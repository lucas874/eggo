#include "POPstates.h"
#include "POPsession.h"

/*             0     	      1     	   2     
 * enum Event {AUTHORIZATION, TRANSACTION, UPDATE};
 *
 */


void POPauthorization::Action(POPsession* ps, Event* e) {
	std::cout << "Hello from AUTHORIZATION state" << std::endl;

	if(e->getEventNo() == 0) {
		existingUser = checkUser(ps, e->getData());
		if(existingUser)
			ps->Reply(USER_OK);
		else
			ps->Reply(USER_ERR);
	}
	else if(e->getEventNo() == 1) {
		authorized = checkPass(ps, e->getData());
		if(authorized)
			ps->Reply(PASS_OK);
		else
			ps->Reply(PASS_ERR);
	}
	else 
		ps->Reply(BAD_CMD_SEQ);


	if(existingUser && authorized)
		ps->currentState = ps->states[1];
}

void POPauthorization::ChangeState(POPsession* ps, int n) {
	if(allowedTransitions[n])
		ps->currentState = ps->states[n];
}

int POPauthorization::getStateNo() {
	return stateNo;
}

bool POPauthorization::checkUser(POPsession* ps, std::string name) {
	User* tmp = ps->uc->LookUp(name);
	if(tmp != nullptr) {		
		ps->setCurrentUser(tmp);
		return true;
	}
	return false;
}

bool POPauthorization::checkPass(POPsession* ps, std::string pass) {	
	if(pass.compare(ps->getCurrentUser()->getPass()) == 0)
		return true;
	else 
		return false;
}

//	       0     1     2     3     4     5     6     7     8
//enum Events {USER, PASS, STAT, LIST, RETR, DELE, NOOP, RSET, QUIT};

void POPtransaction::Action(POPsession* ps, Event* e) {

	switch(e->getEventNo()) {
		case POP_STAT:
			ps->Reply(STAT_OK);
			break;
		case POP_LIST:
			std::string buffer;
			if(e->getData().length() != 0) {
				buffer = e->getData();
				buffer += " ";
				int tmp = ps->getCurrentUser()->getMailSize(std::stoi(e->getData()));
				buffer += std::to_string(tmp);
			}
			else {
				int sz = ps->getCurrentUser()->getInboxSize();
				if(sz == 0) {
					buffer = "Inbox empty\n";
				}
				else {
					for(int i = 0; i < sz; i++) {
						buffer += std::to_string(i);
						buffer += " ";
						buffer += std::to_string(ps->getCurrentUser()->getMailSize(i));
						buffer += "\n";
					} 
				}
			}

			ps->Reply(LIST_OK, buffer);
			break;
	}
}

void POPtransaction::ChangeState(POPsession* ps, int n) {
	if(allowedTransitions[n])
		ps->currentState = ps->states[n];
}

int POPtransaction::getStateNo() {
	return stateNo;
}

void POPupdate::Action(POPsession* ps, Event* ) {
	std::cout << "Hello from UPDATE state" << std::endl;
	ps->Reply(1);
}

void POPupdate::ChangeState(POPsession* ps, int n) {
	if(allowedTransitions[n])
		ps->currentState = ps->states[n];
}

int POPupdate::getStateNo() {
	return stateNo;
}


