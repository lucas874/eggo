#include "PieceOfMail.h"

/*PieceOfMail::PieceOfMail(std::string name) {
  _filename = name;
  fout = new ofstream(_filename, ios:app);

  std::ofstream fout;

  std::string line;

  fout.open(name);

  fout << data << std::endl;

}
*/

/*PieceOfMail::PieceOfMail(std::string name) {
  _filename = name;
  fout = new std::ofstream();

  }*/

void PieceOfMail::append(std::string data) {
  fout->open(_filename);
  
  *fout << data;
  fout->close();

}




