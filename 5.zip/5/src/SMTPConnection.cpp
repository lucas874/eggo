#include "SMTPConnection.h"

SMTPConnection::SMTPConnection(std::vector<SMTPState*> v)
  : states(v)
  , _state(v[0])
  , context(1)
  , socket(context, zmq::socket_type::rep)
  {
   socket.bind("tcp://*:5555");
  }

void SMTPConnection::Run() {
  while(1) {
    
    //char* buffer = s_recv(this->_connection->socket);

    zmq::message_t rawrequest;
    socket.recv(rawrequest, zmq::recv_flags::none);
    std::string request = rawrequest.to_string();
    std::cout << "Received " << request << std::endl;

    /*if(strlen(buffer) > MAX_CMD)
      Reply(500);*/
    

    

    EventData* r = ProcessRequest(request);
    

    //std::cout << "Received request "<< buffer << std::endl;

    ChangeState(r);

    if(r->getEventNo() != 7)
      _state->Action(this);
    else
      Reply(220);
    
  }
}

void SMTPConnection::Close() {
  std::cout << "hej";
}

void SMTPConnection::Reply(int replycode) {
  std::string buffer;
  
  switch(replycode) {
  case SERVICE_READY:
    buffer = "220 localhost Service Ready";
    break;
  case SERVICE_CLOSING:
    buffer = "221 localhost Service closing transmission channel";
    break;
  case MAIL_ACTION_OK:
    buffer = "250 Requested mail action okay, completed";
    break;
  case USER_NOT_LOCAL_FORWARDED:
    buffer = "User not local; will forward to <forward-path>";
    break;
  case START_MAIL_INPUT:
    buffer = "Start mail input end with <CRLF>.<CRLF>";
    break;
  case SERVICE_NA_CLOSING:
    buffer = " localhost Service not available, closing transmission channel";
    break;
  case FAIL_MAILBOX_UNAVAILABLE:
    buffer = "Mailbox unavailable";
    break;
  case ERROR_IN_PROCESSING:
    buffer = " ";
    break;
  case FAIL_INSUFFICIENT_STORAGE:
    buffer = " ";
    break;
  case SYNTAX_ERROR_COMMAND_NOT_RECOGNIZED:
    buffer = " ";
    break;
  case SYNTAX_ERROR_IN_ARGUMENTS:
    buffer = " ";
    break;
  case COMMAND_NOT_IMPLEMENTED:
    buffer = " ";
    break;
  case BAD_COMMAND_SEQUENCE:
    buffer = " ";
    break;
  case PARAMETER_NOT_IMPLEMENTED:
    buffer = " ";
    break;
  case MAILBOX_NOT_FOUND:
    buffer = " ";
    break;
  case USER_NOT_LOCAL:
    buffer = " ";
    break;
  case MAIL_ACTION_ABORT_STORAGE:
    buffer = " ";
    break;
  case MAILBOX_SYNTAX_ERROR:
    buffer = " ";
    break;
  case TRANSACTION_FAILED:
    buffer = " ";
    break;
  }

  //s_send(this->_connection->socket, buffer);
  socket.send(zmq::buffer(buffer), zmq::send_flags::none);
}

EventData* SMTPConnection::ProcessRequest(std::string buffer) {
   std::string CMD(4, ' ');
   //std::string data = buffer;
   
   for(int i = 0; i < 4; i++)
     CMD[i] = buffer[i];

   transform(CMD.begin(), CMD.end(), CMD.begin(), ::tolower);

   enum Event e;

   /*
    * Not very good with long else if statements,
    * but on the other hand this part of the code
    * is unlikely to change (changes if RFC-821 changes) 
    * and with 8 cases is ok. 
    */
   if(CMD.compare("helo") == 0) {
     //do something
     e = HELO;
     
   }
   else if(CMD.compare("ehlo") == 0) {
     e = HELO;
     
   }
   else if(CMD.compare("mail") == 0) {
     e = MAIL;
     
   }
   else if(CMD.compare("rcpt") == 0) {
     e = RCPT;
     
   }
   else if(CMD.compare("data") == 0) {
     e = DATA;
     
   }
   else if(CMD.compare("rset") == 0) {
     e = RSET;
     
   }
   else if(CMD.compare("noop") == 0) {
     e = NOOP;
     //Reply(250);
     
     // NOOP doesn't cause a state transition
     // this value is never used
     
   }
   else if(CMD.compare("quit") == 0) {
     e = QUIT;
     
   }

   EventData *event = new EventData(e, buffer);

   return event;
 }

void SMTPConnection::ChangeState(SMTPState* s) {
  _state = s;
}

void SMTPConnection::ChangeState(EventData* e) {
  if(e->getEventNo() == 7){}
  else
  _state = states[e->getEventNo()];
}
  
void SMTPConnection::StateAction() {
  _state->Action(this);
}
