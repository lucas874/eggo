#include "User.h"

void User::newPieceOfMail() {

  std::string filename = std::to_string(getInboxSize());

  // File format of letter in users inbox
  filename.append(".txt");
  std::string fullpath = getPath();
  fullpath.append(filename);

  
  //PieceOfMail* pieceofmail = new PieceOfMail(fullpath);

  _inbox.push_back(new PieceOfMail(fullpath));
  
  
}

int User::getInboxSize() {
  return _inbox.size();
}

std::string User::getPath() {
  std::string path;

  path.append("Users");
  path.append("/");
  path.append(getUsername());
  path.append("/");
  path.append("Inbox");
  path.append("/");
  return path;
}
  

void User::printpath() {
  std::cout << getPath();
}

/*std::string User::getlatest() {
  std::string str = std::to_string(getInboxSize()+1);
  //std::stringstream ss;
  //ss << getInboxSize()+1;
  //str = ss.str();
  return str;
  }*/

PieceOfMail* User::getlatest() {
  return _inbox[_inbox.size()-1];
}
