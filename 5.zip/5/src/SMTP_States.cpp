#include "SMTP_States.h"
#include "SMTPConnection.h"

void SMTPInit::Action(SMTPConnection* sc) {
  std::cout << "hello from Init Action()" << std::endl;
  sc->Reply(250);
}


void SMTPHelo::Action(SMTPConnection* sc) {
  std::cout << "hello from Helo Action()" << std::endl;
  sc->Reply(250);
}


void SMTPMail::Action(SMTPConnection* sc) {
  std::cout << "hello from Mail Action()" << std::endl;
  sc->Reply(250);
}


void SMTPRcpt::Action(SMTPConnection* sc) {
  std::cout << "hello from Rcpt Action()" << std::endl;
  sc->Reply(250);
}


void SMTPData::Action(SMTPConnection* sc) {
  std::cout << "hello from Data Action()" << std::endl;
  sc->Reply(354);
}

void SMTPRset::Action(SMTPConnection* sc) {
  std::cout << "hello from Rset Action()" << std::endl;
  sc->Reply(250);
}


void SMTPQuit::Action(SMTPConnection* sc) {
  std::cout << "hello from Quit Action()" << std::endl;
  sc->Reply(221);
}
