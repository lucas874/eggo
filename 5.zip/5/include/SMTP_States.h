#pragma once
#include "SMTPState.h"
#include <iostream>

class SMTPInit : public SMTPState {
public:
  void Action(SMTPConnection* sc) override;
  
};

class SMTPHelo : public SMTPState {
public:
  void Action(SMTPConnection* sc) override;
};


class SMTPMail : public SMTPState {
public:
  void Action(SMTPConnection* sc) override;
};

class SMTPRcpt : public SMTPState {
public:
  void Action(SMTPConnection* sc) override;
};


class SMTPData : public SMTPState {
public:
  void Action(SMTPConnection* sc) override;
};

class SMTPRset : public SMTPState {
public:
  void Action(SMTPConnection* sc) override;
};

class SMTPQuit : public SMTPState {
public:
  void Action(SMTPConnection* sc) override;
};
