#ifndef _SMTPSTATE_H_
#define _SMTPSTATE_H_
class SMTPConnection;
//#include "SMTPConnection.h"
// Doesn't inherit from a Singleton class but is an implementation of a Singleton directly
class SMTPState {
  
 public:
  
  virtual void Close(SMTPConnection*);
  virtual void Send(SMTPConnection*);
  virtual void Action(SMTPConnection*);
};

#endif
