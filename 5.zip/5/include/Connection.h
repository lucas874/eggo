#ifndef _CONNECTION_H_
#define _CONNECTION_H_
#include <zmq.hpp>

/*
 * struct with stuff for network communication
 * context and socket
 */
class Connection {
 public:
  Connection();
  ~Connection();
 private:
  zmq::context_t *context;
  zmq::context_t *socket;
};


#endif
