#ifndef _USERS_H_
#define _USERS_H_

#include "Globals.h"
#include "PieceOfMail.h"
#include <vector>
#include <iostream>

class User {
public:
  User(std::string username) : _username(username) {
    _inbox.resize(1);
 };
  
  const std::string& getUsername() const {
    return _username;
  }
  
  bool operator==(const User & rhs) const {
    return getUsername() == rhs.getUsername();
  }

   bool operator!=(const User & rhs) const {
     return !(*this == rhs);
  }

  
  void newPieceOfMail();
  int getInboxSize();
  void printpath();
  PieceOfMail* getlatest();
  std::string getPath();
  
 private:
  friend class SMTPConnection;
  std::string _username;
  std::string _domain;
  std::vector<PieceOfMail*> _inbox;
  

};

/*namespace std {
  template <>
  class hash<string> {
  public:
    size_t operator()(const string& item) {
      static hash<string> hf;
      return hf(item);
    }
  };
  }*/

#endif

  
  
  

