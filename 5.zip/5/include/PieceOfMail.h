#ifndef _PIECEOFMAIL_H_
#define _PIECEOFMAIL_H_

#include <fstream>

class PieceOfMail {
 private:
  std::string _filename;
  std::ofstream *fout;
  //std::string _data;
 public:
  PieceOfMail(std::string name) : _filename(name), fout(new std::ofstream(name, std::ios::app)) {};
  void append(std::string data);
  //void Write(std::string data);
};


#endif
