#ifndef _USERCOLLECTION_H_
#define _USERCOLLECTION_H_

#include <User.h>

class UserCollection {
public:
  UserCollection();
  void addUser(User*);
  void removeUser(User*);
  User* LookUp(std::string);
  int lookup(std::string);
private:
  std::vector<User*> _users;
  std::hash<std::string> _hash;
};
  
#endif
