#ifndef _SMTPCONNECTION_H_
#define _SMTPCONNECTION_H_

#include "SMTP_States.h"
#include "globals.h"
//#include "Connection.h"
#include "EventData.h"

#include <iostream>
#include <algorithm>
#include <unistd.h>
#include <string>
#include <cstring>
#include <vector>
#include <zmq.hpp>

class SMTPState;

class SMTPConnection {
 public:
  SMTPConnection(std::vector<SMTPState*> v);
  void Run();
  void Close();
  void Reply(int replycode);
  EventData* ProcessRequest(std::string buffer);
  std::string getTextLine(char *buffer);
  void StateAction();
  void ChangeState(EventData*);
  

 private:
  friend class SMTPState;
  void ChangeState(SMTPState*);
  //void ChangeState(EventData*);
  SMTPState* _state;
  std::vector<SMTPState*> states;
  //Connection* _connection;
  zmq::context_t context;
  zmq::socket_t socket;
  /*std::string senderDomain;
  std::string senderUserName;
  std::string rcptDomain;
  std::string rcptUsername;*/
  
};

#endif
