#include "POPevent.h"

POPevent::POPevent(int event, std::string data) {
    _event = event;
    _data = data;
}

/*
 * public methods for getting data, event and state number
 */
std::string POPevent::getData() {
  return _data;
}

int POPevent::getEventNo() {
  return _event;
}




 
