#include <iostream>
#include "SMTPConnection.h"
#include "SMTP_States.h"
#include "UserCollection.h"

using namespace std;

vector<SMTPState*> initializeV() {
  vector<SMTPState*> v(7);
  v[0] = new SMTPInit();
  v[1] = new SMTPHelo();
  v[2] = new SMTPMail;
  v[3] = new SMTPRcpt;
  v[4] = new SMTPData;
  v[5] = new SMTPRset;
  v[6] = new SMTPQuit;

  return v;
}
  
int main() {
  
  vector<SMTPState*> v = initializeV();

  
  UserCollection *uc = new UserCollection;
  //UserCollection uc();
  
  User a_user("Alice");
  User b_user("Bob");

  uc->addUser(&a_user);
  //uc->addUser(&b_user);
  

  
  SMTPConnection SC(v, uc);

  //SC.StateAction();

  SC.Run();
  //enum Event e = MAIL;
  //string str = "bjarnebjarne";

  //EventData ed(e, str);
  //SC.ChangeState(&ed);
  //SC.StateAction();
}
