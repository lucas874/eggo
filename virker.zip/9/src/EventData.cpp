#include "EventData.h"

EventData::EventData(enum Event event, std::string data) {
    _event = event;
    _data = new std::string;
    *_data = data;
}

/*EventData::setEvent(enum Event event) {
	_event = event;
}

EventData::setData(std::string data) {
	_data = data;
}
*/

std::string EventData::getData() {
  return *_data;
}

int EventData::getEventNo() {
  return _event;
}






  
