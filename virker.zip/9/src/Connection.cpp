#include "Connection.h"

Connection::Connection() {
  context{1};
  socket{context, zmq::socket_type::rep}
  socket.bind("tcp://*:5555");
 }
