
#include "SMTPState.h"

//class SMTPConnection;
// inject SMTPConnection in constructor!!
void SMTPState::Close(SMTPConnection*) { }
void SMTPState::Send(SMTPConnection*) { }
void SMTPState::Action(SMTPConnection*, EventData*) { }
void SMTPState::ChangeState(SMTPConnection*, int) { }
int SMTPState::getStateNo() {}
