#include "SMTP_States.h"
#include "SMTPConnection.h"

void SMTPInit::Action(SMTPConnection* sc, EventData* e) {
  //std::cout << "hello from Init Action()" << std::endl;
  sc->Reply(250);
}

void SMTPInit::ChangeState(SMTPConnection* sc, int n) {
	if(allowedTransitions[n])
		sc->_state = sc->states[n];
}

int SMTPInit::getStateNo() {
	return stateNo;
}

void SMTPHelo::Action(SMTPConnection* sc, EventData* e) {
  std::cout << "hello from Helo Action()" << std::endl;
  std::string str = sc->getCurData().substr(5);
  sc->setSenderDomain(str);
  
  sc->Reply(250);
}

void SMTPHelo::ChangeState(SMTPConnection* sc, int n) {
	if(allowedTransitions[n])
		sc->_state = sc->states[n];
}

int SMTPHelo::getStateNo() {
	return stateNo;
}


void SMTPMail::Action(SMTPConnection* sc, EventData* e) {
  std::cout << "hello from Mail Action()" << std::endl;
  std::string str = sc->getCurData();
  int i = 0;
  while(str[i] != '@')
    i++;

  std::string name;
  name = str.substr(0,i);

  sc->setSenderUsername(name);
  sc->curmail = new PieceOfMail("0.txt");
  sc->curmail->setsender(name);
  sc->Reply(250);

}

void SMTPMail::ChangeState(SMTPConnection* sc, int n) {
	if(allowedTransitions[n])
		sc->_state = sc->states[n];
}

int SMTPMail::getStateNo() {
	return stateNo;
}

void SMTPRcpt::Action(SMTPConnection* sc, EventData* e) {
  std::cout << "hello from Rcpt Action()" << std::endl;
  std::string str = sc->getCurData();
  std::string domain;
  std::string name;

  int i = 0;
  while(str[i] != '@')
    i++;

  
  //sc->rcptUsername = str.substr(0, i);
  //sc->rcptDomain = str.substr(i+1);
  name = str.substr(0,i);
  domain = str.substr(i+1);

  
  if(sc->rcptDomain.compare(DOMAIN_NAME) != 0) {
    sc->Reply(551);
    return;
  }
  else {
    sc->rcpt = sc->_uc->LookUp(name);
  }

  //sc->curmail = PieceOfMail("0.txt", );
  sc->curmail->setrcpt(name);
  sc->Reply(250);
}

void SMTPRcpt::ChangeState(SMTPConnection* sc, int n) {
	if(allowedTransitions[n])
		sc->_state = sc->states[n];
}

int SMTPRcpt::getStateNo() {
	return stateNo;
}

void SMTPData::Action(SMTPConnection* sc, EventData* e) {
	if(sc->curmail->getContent().empty()) {
		std::cout << "hello from Data Action()" << std::endl;
		sc->curmail->append("dhakjsdhK");
		sc->Reply(354);
	}
	else {
		/*if(e->getData().substr(0,5).compare("\r\f.\r\f") == 0) {
			//sc->Reply(250);
			ChangeState(sc, 1);
			sc->Reply(250);
		}
		else {*/
			sc->curmail->append(e->getData());
			sc->Reply(250);
		//}
	}
}

void SMTPData::append(SMTPConnection* sc, EventData* e) {
	//if(e->getData().compare(END_DATA) != 0)
	//	sc->curmail->append(e->getData());
	//else
		ChangeState(sc, 1);
}


void SMTPData::ChangeState(SMTPConnection* sc, int n) {
	if(allowedTransitions[n])
		sc->_state = sc->states[n];
}

int SMTPData::getStateNo() {
	return stateNo;
}

void SMTPRset::Action(SMTPConnection* sc, EventData* e) {
  std::cout << "hello from Rset Action()" << std::endl;
  sc->Reply(250);
}

void SMTPRset::ChangeState(SMTPConnection* sc, int n) {
	if(allowedTransitions[n])
		sc->_state = sc->states[n];
}
int SMTPRset::getStateNo() {
	return stateNo;
}

void SMTPQuit::Action(SMTPConnection* sc, EventData* e) {
  std::cout << "hello from Quit Action()" << std::endl;
  sc->Reply(221);
}

void SMTPQuit::ChangeState(SMTPConnection* sc, int n) {
	if(allowedTransitions[n])
		sc->_state = sc->states[n];
}

int SMTPQuit::getStateNo() {
	return stateNo;
}
