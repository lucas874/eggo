#include "PieceOfMail.h"

PieceOfMail::PieceOfMail(std::string name) {
  _filename = new std::string(name);	
  //_filename = name;
  _rcpt = new std::string;
  _sender = new std::string;
  content = new std::string;
}

void PieceOfMail::append(std::string data) {
  content->append(data);
}

std::string PieceOfMail::getContent() {
  return *content;
}

void PieceOfMail::setrcpt(std::string rcpt) {
	*_rcpt = rcpt;
}

void PieceOfMail::setsender(std::string sender) {
	*_sender = sender;
}
