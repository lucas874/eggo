### README

This is an implementation of the SMTP as defined in [RFC-821](https://tools.ietf.org/html/rfc821). It is in no way done yet. It is implemented as a state machine with states corresponding to the different commands that an implementation of SMTP must have, HELO, MAIL etc. The state transition logic should be working, but the stuff that must  be done in each state (such as in MAIL state create new file, in RCPT check if recipient is local user and if this is the case get path to inbox) has not been implemented yet. 



### Build instructions 

ZeroMQ for C++ should be installed on the machine. Install instructions can be found [here](https://github.com/zeromq/cppzmq).

In top folder run mkdir build. 

cd build

cmake ..

make 



