//#ifndef _SMTPCONNECTION_H_
//#define _SMTPCONNECTION_H_

#pragma once
#include "SMTP_States.h"
#include "Globals.h"
//#include "User.h"
#include "EventData.h"
#include "UserCollection.h"
#include "PieceOfMail.h"

#include <iostream>
#include <algorithm>
#include <unistd.h>
#include <string>
#include <cstring>
#include <vector>
#include <zmq.hpp>

class SMTPState;
/*class SMTPState;
class SMTPInit;
class SMTPHelo;
class SMTPMail;
class SMTPRcpt;
class SMTPData;
class SMTPQuit;
class SMTPRset;
*/

class SMTPConnection {
 public:
  SMTPConnection(std::vector<SMTPState*> v, UserCollection* u);
  void Run();
  void Close();
  void Reply(int replycode);
  EventData* ProcessRequest(std::string buffer);
  void processTextLine(std::string buffer);
  void StateAction();
  void ChangeState(EventData*);
  void setSenderDomain(std::string);
  void setSenderUsername(std::string);
  void setRcptDomain(std::string);
  void setRcptUsername(std::string);
  std::string getCurData();
  

 private:
  friend class SMTPState;
  friend class SMTPInit;
  friend class SMTPHelo;
  friend class SMTPMail;
  friend class SMTPRcpt;
  friend class SMTPData;
  friend class SMTPQuit;
  friend class SMTPRset;

  void ChangeState(SMTPState*);
  //void ChangeState(EventData*);
  SMTPState* _state;
  UserCollection* _uc;
  std::vector<SMTPState*> states;
  EventData* currentevent;
  //Connection* _connection;
  zmq::context_t context;
  zmq::socket_t socket;
  std::string senderDomain;
  std::string senderUsername;
  std::string rcptDomain;
  std::string rcptUsername;
  User* rcpt;
  PieceOfMail* curmail;
  std::string currentData;
  
};

//#endif
