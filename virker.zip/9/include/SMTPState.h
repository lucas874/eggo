//#ifndef _SMTPSTATE_H_
//#define _SMTPSTATE_H_

#pragma once
#include <string>
#include "EventData.h"
class SMTPConnection;
//#include "SMTPConnection.h"

class SMTPState {
  
 public:
  
  virtual void Close(SMTPConnection*);
  virtual void Send(SMTPConnection*);
  virtual void Action(SMTPConnection*, EventData*);
  virtual void ChangeState(SMTPConnection*, int);
  virtual int getStateNo();
 };

//#endif
