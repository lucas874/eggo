#pragma once
/*
 * Domain name
 */
#define DOMAIN_NAME "localhost"


/*
 * Marks end of mail content transmission
 */
#define END_DATA "\r\n.\r\n"
//#define END_DATA "<CRLF>.<CRLF>"
/*
 * Reply codes as defined in RFC-821
 *
 */
#define SYSTEM_STATUS 211
#define HELP_MESSAGE 214
#define SERVICE_READY 220
#define SERVICE_CLOSING 221
#define MAIL_ACTION_OK 250
#define USER_NOT_LOCAL_FORWARDED 251
#define START_MAIL_INPUT 354 //end with <CRLF>.<CRLF>
#define SERVICE_NA_CLOSING 421
#define FAIL_MAILBOX_UNAVAILABLE 450
#define ERROR_IN_PROCESSING 451
#define FAIL_INSUFFICIENT_STORAGE 452
#define SYNTAX_ERROR_COMMAND_NOT_RECOGNIZED 500
#define SYNTAX_ERROR_IN_ARGUMENTS 501
#define COMMAND_NOT_IMPLEMENTED 502
#define BAD_COMMAND_SEQUENCE 503
#define PARAMETER_NOT_IMPLEMENTED 504
#define MAILBOX_NOT_FOUND 550
#define USER_NOT_LOCAL 551
#define MAIL_ACTION_ABORT_STORAGE 552
#define MAILBOX_SYNTAX_ERROR 553
#define TRANSACTION_FAILED 554


/*
 * Maximum lengths
 */
#define MAX_USERNAME 64
#define MAX_DOMAIN 64
#define MAX_CMD 512
#define MAX_REPLY 512
#define MAX_TEXT_LINE 1000
#define MAX_RCPTS 100

/*
 *
 * Server states
 *
 */

#define STATE_INIT 0
#define STATE_HELO 1
#define STATE_MAIL 2
#define STATE_RCPT 3
#define STATE_DATA 4
#define STATE_RSET 5
#define STATE_QUIT 6
//#define NOOP 7
/*

211 System status, or system help reply
         214 Help message
            [Information on how to use the receiver or the meaning of a
            particular non-standard command; this reply is useful only
            to the human user]
         220 <domain> Service ready
         221 <domain> Service closing transmission channel
         250 Requested mail action okay, completed
         251 User not local; will forward to <forward-path>

         354 Start mail input; end with <CRLF>.<CRLF>

         421 <domain> Service not available,
             closing transmission channel
            [This may be a reply to any command if the service knows it
            must shut down]
         450 Requested mail action not taken: mailbox unavailable
            [E.g., mailbox busy]
         451 Requested action aborted: local error in processing
         452 Requested action not taken: insufficient system storage

         500 Syntax error, command unrecognized
            [This may include errors such as command line too long]
         501 Syntax error in parameters or arguments
         502 Command not implemented
         503 Bad sequence of commands
         504 Command parameter not implemented
         550 Requested action not taken: mailbox unavailable
            [E.g., mailbox not found, no access]
         551 User not local; please try <forward-path>
         552 Requested mail action aborted: exceeded storage allocation
         553 Requested action not taken: mailbox name not allowed
            [E.g., mailbox syntax incorrect]
         554 Transaction failed

 */
