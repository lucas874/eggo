#ifndef _HASHTABLECHAIN_H_
#define _HASHTABLECHAIN_H_


#include <vector>
#include <list>
#include <string>
#include <algorithm>
#include <functional>

int nextPrime(int n);
bool isPrime(int n);

class HashTable {
 public:
 HashTable(int size = 101) : currentSize{0} {
    theLists.resize(nextPrime(size));
  }

  void makeEmpty();
  bool contains(const 
