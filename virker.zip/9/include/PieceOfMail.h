//#ifndef _PIECEOFMAIL_H_
//#define _PIECEOFMAIL_H_

#pragma once
#include <vector>
#include <string>

class PieceOfMail {
 private:
  std::string *_filename;
  std::string *_rcpt;
  std::string *_sender;
  // Complete piece of mail is stored on heap as an intermediate state
  std::string *content;
 public:
  PieceOfMail(std::string filename);
  void append(std::string data);
  std::string getContent();
  void setrcpt(std::string rcpt);
  void setsender(std::string sender);
};


//#endif
